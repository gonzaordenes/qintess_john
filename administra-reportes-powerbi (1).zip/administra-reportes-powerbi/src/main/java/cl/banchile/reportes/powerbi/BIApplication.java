package cl.banchile.reportes.powerbi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Clase principal de la ejecución
 * Inicia y mantiene la aplicación en ejecución e inicializa el contexto Spring y (auto)configuraciones
 */
@SpringBootApplication

public class BIApplication {
	/**
	 * Metodo main
	 * @param args argumentos
	 */
	public static void main(String[] args) {
		SpringApplication.run(BIApplication.class, args);
	}


}
