package cl.banchile.reportes.powerbi.application.adapters.in.rest;

import cl.banchile.reportes.powerbi.application.adapters.in.rest.model.CatalogResponseBody;
import cl.banchile.reportes.powerbi.application.adapters.in.rest.model.ReportesResponseBody;
import cl.banchile.reportes.powerbi.application.adapters.out.events.ResponseHandler;
import cl.banchile.reportes.powerbi.domain.ports.in.DomainQueryPort;
import cl.banchile.reportes.powerbi.domain.ports.in.DomainQueryPortReports;
import io.swagger.v3.oas.annotations.Operation;
import java.util.List;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * Clase de implementación de Adaptador Rest Rest Controller
 */
@Slf4j
@RestController
// Raiz de URI Rest controller concide con lineamientos de arquitectura
// se considera en nombre del contexto, la versión y el dominio del servicio
@RequestMapping(path = "/${archetype.context-name}/${archetype.current-version}/${archetype.domain-name}")
/*
 * @OpenAPIDefinition( info = @Info( title =
 * "Banchile Dominio Catalogs Rest API", version = "1" ) )
 */public class CatalogosController {

    private final DomainQueryPortReports domainQueryDrivingPort;
    private final DomainQueryPort domainQueryDrivingPort1;
    private static final String MESSAGE = "Datos Recuperados";

    /**
     * Constructor con inyección de dependencias
     *
     * @param domainCommandDrivingPort puerto de comandos al dominio
     * @param domainQueryDrivingPort puerto de consultas al dominio
     */
    public CatalogosController(@Autowired final DomainQueryPortReports domainQueryDrivingPort,
                               @Autowired final DomainQueryPort domainQueryDrivingPort1) {
        this.domainQueryDrivingPort = domainQueryDrivingPort;
        this.domainQueryDrivingPort1 = domainQueryDrivingPort1;
    }

    /**
     * obtener una lista de los Catalogos disponibles
     *
     * @return lista de los Catalogos disponibles
     */
    @GetMapping("/catalogos")
    @Operation(summary = "Recupera todos los reportes disponibles en ReportServer")
    public ResponseEntity<Object> obtenerCatalogos() {
        CatalogosController.log.info("Rest Adapter obtener Catalogos");
        // Llamando al servicio de dominio obtenerCatalogos
        final List<CatalogResponseBody> lista = this.domainQueryDrivingPort.obtenerCatalogos()
            .stream()
            .map(catalogModel -> CatalogResponseBody.builder()
                .itemId(catalogModel.getItemId())
                .nombre(catalogModel.getName())
                .path(catalogModel.getPath())
                .type(catalogModel.getType())
                .build())
            .collect(Collectors.toList());
        CatalogosController.log.info("Rest data obtener Catalogos");
        return ResponseHandler
            .generateResponse("0", CatalogosController.MESSAGE, HttpStatus.OK, lista);
    }

    @GetMapping("/catalogos-filtrados")
    @Operation(summary = "Recupera desde ReportServer solo los catalogos tipo 13 o 2")
    public ResponseEntity<Object> obtenerCatalogosv2() {
        final List<ReportesResponseBody> listarepocat = this.domainQueryDrivingPort1.obtenerReportes().stream()
            .map(reporteModel -> ReportesResponseBody.builder()
                .ideReporte(reporteModel.getIdeReporte())
                .ideCategoria(reporteModel.getIdeCategoria())
                .codEstado(reporteModel.getCodEstado())
                .fecCreacion(reporteModel.getFecCreacion())
                .usrCreacion(reporteModel.getUsrCreacion())
                .fecBaja(reporteModel.getFecBaja())
                .usrBaja(reporteModel.getUsrBaja())
                .build())
            .collect(Collectors.toList());

        CatalogosController.log.info("Rest Adapter obtener Catalogos Filtrados");
        // Llamando al servicio de dominio obtenerCatalog
        final List<CatalogResponseBody> lista = this.domainQueryDrivingPort.obtenerCatalog().stream()
            .map(catalogModel -> CatalogResponseBody.builder()
                .itemId(catalogModel.getItemId())
                .categoria(listarepocat.stream()
                    .filter(x -> catalogModel.getItemId().toString().equals(x.getIdeReporte()))
                    .findAny()
                    .orElse(new ReportesResponseBody()).getIdeCategoria())
                .nombre(catalogModel.getName())
                .path(catalogModel.getPath())
                .type(catalogModel.getType())
                .build())
            .collect(Collectors.toList());
        return ResponseHandler.generateResponse("0", CatalogosController.MESSAGE, HttpStatus.OK, lista);
    }

    @GetMapping("/catalogos-usuario/{dominio}/{user}")
    @Operation(summary = "Recupera los catalogos disponibles para el usuario, invocacion tipo dominio/user")
    public ResponseEntity<Object> obtenerCatalogosv3(@PathVariable(name = "dominio",
        required = false) final String dominio,
        @PathVariable(name = "user", required = false) final String user) {
        final String usuario = dominio + "\\" + user;
        CatalogosController.log.info("Rest Adapter obtener Catalogos Filtrados para el usuario");
        // Llamando al servicio de dominio obtenerUsuarios
        final List<ReportesResponseBody> listarepocat = this.domainQueryDrivingPort1.obtenerReportes().stream()
            .map(reporteModel -> ReportesResponseBody.builder()
                .ideReporte(reporteModel.getIdeReporte())
                .ideCategoria(reporteModel.getIdeCategoria())
                .codEstado(reporteModel.getCodEstado())
                .fecCreacion(reporteModel.getFecCreacion())
                .usrCreacion(reporteModel.getUsrCreacion())
                .fecBaja(reporteModel.getFecBaja())
                .usrBaja(reporteModel.getUsrBaja())
                .build())
            .collect(Collectors.toList());

        final List<CatalogResponseBody> lista = this.domainQueryDrivingPort.obtenerCatalogUser(usuario).stream()
            .map(catalogModel -> CatalogResponseBody.builder()
                .itemId(catalogModel.getItemId())
                .categoria(listarepocat.stream()
                    .filter(x -> catalogModel.getItemId().toString().equals(x.getIdeReporte()))
                    .findAny()
                    .orElse(new ReportesResponseBody()).getIdeCategoria())
                .nombre(catalogModel.getName())
                .path(catalogModel.getPath())
                .type(catalogModel.getType())
                .build())
            .collect(Collectors.toList());

        return ResponseHandler.generateResponse("0", CatalogosController.MESSAGE, HttpStatus.OK, lista);
    }

}
