package cl.banchile.reportes.powerbi.application.adapters.in.rest;

import java.util.List;
import java.util.stream.Collectors;
import java.sql.Date;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import cl.banchile.reportes.powerbi.application.adapters.in.rest.model.CategoriaRequestBody;
import cl.banchile.reportes.powerbi.application.adapters.in.rest.model.CategoriaRequestBodyUpdate;
import cl.banchile.reportes.powerbi.application.adapters.in.rest.model.CategoriaResponseBody;
import cl.banchile.reportes.powerbi.application.adapters.out.events.ResponseHandler;
import cl.banchile.reportes.powerbi.domain.model.domain.CategoriaModel;
import cl.banchile.reportes.powerbi.domain.model.to.CrearResourceResponse;
import cl.banchile.reportes.powerbi.domain.ports.in.DomainCommandPort;
import cl.banchile.reportes.powerbi.domain.ports.in.DomainQueryPort;
import io.swagger.v3.oas.annotations.Operation;
import lombok.extern.slf4j.Slf4j;


/**
 * Clase de implementación de Adaptador Rest Rest Controller
 */
@Slf4j
@RestController
// Raiz de URI Rest controller concide con lineamientos de arquitectura
// se considera en nombre del contexto, la versión y el dominio del servicio
@RequestMapping(path = "/${archetype.context-name}/${archetype.current-version}/${archetype.domain-name}/categorias")
public class CategoriasController {
	private DomainCommandPort domainCommandDrivingPort;
	private DomainQueryPort domainQueryDrivingPort;
	
	/**
	 * Constructor con inyección de dependencias
	 * 
	 * @param domainCommandDrivingPort puerto de comandos al dominio
	 * @param domainQueryDrivingPort   puerto de consultas al dominio
	 */
	public CategoriasController(@Autowired DomainCommandPort domainCommandDrivingPort,
			@Autowired DomainQueryPort domainQueryDrivingPort) {
		this.domainCommandDrivingPort = domainCommandDrivingPort;
		this.domainQueryDrivingPort = domainQueryDrivingPort;
	}

	/**
	 * obtener una lista de los Categorias
	 * 
	 * @return lista con las Categorias
	 */
	@GetMapping("")
	@Operation(summary = "Servicio que permite listar todas las categorias disponibles")
	public ResponseEntity<Object> obtenerCategorias() {
		log.info("Rest Adapter obtener Categorias");
		// Llamando al servicio de dominio obtenerCategorias
		List<CategoriaResponseBody> lista = domainQueryDrivingPort.obtenerCategorias().stream()
				.map(categoriaModel -> CategoriaResponseBody.builder()
						.ideCategoria(String.valueOf(categoriaModel.getIdeCategoria()))
						.nomCategoria(categoriaModel.getNomCategoria())
						.codEstado(categoriaModel.getCodEstado())
						.codColor(categoriaModel.getCodColor())
						.codHobberColor(categoriaModel.getCodHobberColor())
						.catImagen(categoriaModel.getCatImagen())
						.fecCreacion(categoriaModel.getFecCreacion())
						.usrCreacion(categoriaModel.getUsrCreacion())
						.fecBaja(categoriaModel.getFecBaja())
						.usrBaja(categoriaModel.getUsrBaja())
						.build())
				.collect(Collectors.toList());
		return ResponseHandler.generateResponse("0", "Datos Recuperados", HttpStatus.OK, lista);
	}

	/**
	 * Obtiene una Categoria, identificada por su id
	 * 
	 * @param ideCategoria identificador de la categoria
	 * @return Response con la Categoria
	 */
	@GetMapping("/{id}")
	@Operation(summary = "Servicio que permite recuperar categoria por id")
	public ResponseEntity<Object> obtenerCategoria(@PathVariable(name = "id", required = false) Integer ideCategoria) {
		log.info("Rest Adapter obtenerCategoria");

		// Llamando el servicio de dominio obtenerMaestro, por identificador
		CategoriaModel categoriaModel = domainQueryDrivingPort.obtenerCategoria(ideCategoria);

		return ResponseHandler.generateResponse("0", "Datos Recuperados", HttpStatus.OK, categoriaModel);
	}

	/**
	 * Crear una Categoria
	 * 
	 * @param crearCategoriaRequest cuerpo de la solicitud
	 * @return response con los detalles de la creación de la categoria
	 */

	@PostMapping("") 
	@Operation(summary = "Servicio que permite crear nueva categoria")
	public ResponseEntity<CrearResourceResponse>
	crearCategoria(@Valid @RequestBody CategoriaRequestBody crearCategoriaRequest){
		log.info("Rest Adapter crearCategoria");
		Date date = new Date(System.currentTimeMillis());
		CategoriaModel command = CategoriaModel.builder()
				.nomCategoria(crearCategoriaRequest.getNomCategoria())
				.codEstado("A")
				.codColor(crearCategoriaRequest.getCodColor())
				.codHobberColor(crearCategoriaRequest.getCodHobberColor())
				.catImagen(crearCategoriaRequest.getCatImagen())
				.fecCreacion(date) 
				.usrCreacion(crearCategoriaRequest.getUsrCreacion())
				.fecBaja(null) 
				.usrBaja(null) 
				.build();

		//llamando al servicio de dominio crearCategoria return new
		return new ResponseEntity<>(domainCommandDrivingPort.crearCategoria(command), HttpStatus.ACCEPTED);
	}

	
	/**
	 * Eliminar una Categoria
	 * 
	 * @param ideCategoria id de la Categoria a Eliminar
	 * @return responseEntity con status OK
	 */
	@DeleteMapping("/{id}")
	@Operation(summary = "Servicio que permite eliminar categoria por id")
	public ResponseEntity<Object> eliminarCategoria(@PathVariable(name = "id", required = true) Integer ideCategoria) {
		log.info("Rest Adapter eliminarCategoria");

		CategoriaModel categoriaModel = domainQueryDrivingPort.obtenerCategoria(ideCategoria);
		String ideCategoria2 = categoriaModel.getNomCategoria();
		if (ideCategoria2.isEmpty()) {
			return ResponseHandler.generateResponse("99", "Datos No Encontrados", HttpStatus.BAD_REQUEST, categoriaModel);
		}
		// llamando al servicio de dominio eliminarUsuario
		domainCommandDrivingPort.eliminarCategoria(ideCategoria);
		return ResponseHandler.generateResponse("0", "Datos Eliminados", HttpStatus.OK, categoriaModel);
	}

	/**
	 * Modificar una Categoria
	 * 
	 * @param updateCategoriaRequestBody cuerpo de la solicitud
	 * @return response con los detalles de la modificacion de la categoria
	 */
	@PutMapping ("") 
	@Operation(summary = "Servicio que permite modificar datos de categoria")
	public ResponseEntity<Object>
	updateCategoria(@Valid @RequestBody CategoriaRequestBodyUpdate updateCategoriaRequestBody){
		log.info("Rest Adapter updateCategoria");
		Date date = new Date(System.currentTimeMillis());
		CategoriaModel command;
		
		if (updateCategoriaRequestBody.getIdeCategoria()==null) { 
            return ResponseHandler.generateResponse("99", "Revisar Datos de Entrada", HttpStatus.BAD_REQUEST, " ");
        }
        else if (updateCategoriaRequestBody.getUsrBaja()!=null) {  // sólo se requiere validar que se quiere dar de baja
        	 command = CategoriaModel.builder()
                    .ideCategoria(updateCategoriaRequestBody.getIdeCategoria())
                    .codEstado("B")
                    .fecCreacion(date)
                    .usrCreacion(updateCategoriaRequestBody.getUsrBaja())
                    .fecBaja(date) 
                    .usrBaja(updateCategoriaRequestBody.getUsrBaja()) 
                    .build();
        }
        else { // por defecto es update full. Si la BD falla se escala el error. Es responsabilidad del front enviar los datos correctos
            command = CategoriaModel.builder()
                    .ideCategoria(updateCategoriaRequestBody.getIdeCategoria())
                    .nomCategoria(updateCategoriaRequestBody.getNomCategoria())
                    .codEstado("A")
                    .codColor(updateCategoriaRequestBody.getCodColor())
                    .codHobberColor(updateCategoriaRequestBody.getCodHobberColor())
                    .catImagen(updateCategoriaRequestBody.getCatImagen())
                    .fecCreacion(date) 
                    .usrCreacion(updateCategoriaRequestBody.getUsrCreacion())
                    .fecBaja(null) 
                    .usrBaja(null) 
                    .build();
        }
		
		//llamando al servicio de dominio crearCategoria return new
		return new ResponseEntity<>(domainQueryDrivingPort.updateCategoria(command), HttpStatus.ACCEPTED);
	}
	
}