package cl.banchile.reportes.powerbi.application.adapters.in.rest;

import java.util.List;
import java.util.stream.Collectors;
import java.sql.Date;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import cl.banchile.reportes.powerbi.application.adapters.in.rest.model.ReporteRequestBody;
import cl.banchile.reportes.powerbi.application.adapters.in.rest.model.ReporteRequestBodyUpdate;
import cl.banchile.reportes.powerbi.application.adapters.in.rest.model.ReportesResponseBody;
import cl.banchile.reportes.powerbi.application.adapters.out.events.ResponseHandler;
import cl.banchile.reportes.powerbi.common.utils.Utils;
import cl.banchile.reportes.powerbi.domain.model.domain.CategoriaModel;
import cl.banchile.reportes.powerbi.domain.model.domain.ReporteModel;
import cl.banchile.reportes.powerbi.domain.ports.in.DomainCommandPort;
import cl.banchile.reportes.powerbi.domain.ports.in.DomainQueryPort;
import io.swagger.v3.oas.annotations.Operation;
import lombok.extern.slf4j.Slf4j;

/**
 * Clase de implementación de Adaptador Rest Controller
 */
@Slf4j
@RestController
// Raiz de URI Rest controller concide con lineamientos de arquitectura
// se considera en nombre del contexto, la versión y el dominio del servicio
@RequestMapping(path = "/${archetype.context-name}/${archetype.current-version}/${archetype.domain-name}")
public class ReportesController {
	private DomainCommandPort domainCommandDrivingPort;
	private DomainQueryPort domainQueryDrivingPort;

	
	/**
	 * Constructor con inyección de dependencias
	 * 
	 * @param domainCommandDrivingPort puerto de comandos al dominio
	 * @param domainQueryDrivingPort   puerto de consultas al dominio
	 */
	public ReportesController(@Autowired DomainCommandPort domainCommandDrivingPort,
			@Autowired DomainQueryPort domainQueryDrivingPort) {
		this.domainCommandDrivingPort = domainCommandDrivingPort;
		this.domainQueryDrivingPort = domainQueryDrivingPort;
	}

	/**
	 * obtener una lista de los Reportes
	 * 
	 * @return lista con las Reportes
	 */
	@GetMapping("")
	@Operation(summary = "Servicio que permite listar todos los reportes")
	public ResponseEntity<Object> obtenerReportes() {
		log.info("Rest Adapter obtener Reportes");

		// Llamando al servicio de dominio obtenerCategorias
		List<ReportesResponseBody> lista = domainQueryDrivingPort.obtenerReportes().stream()
				.map(reporteModel->ReportesResponseBody.builder()
						.ideReporte(reporteModel.getIdeReporte())
						.ideCategoria(reporteModel.getIdeCategoria())
						.codEstado(reporteModel.getCodEstado())
						.fecCreacion(reporteModel.getFecCreacion())
						.usrCreacion(reporteModel.getUsrCreacion())
						.fecBaja(reporteModel.getFecBaja())
						.usrBaja(reporteModel.getUsrBaja())
						.nomReporte(reporteModel.getNomReporte())
						.build())		
				.collect(Collectors.toList());
		return ResponseHandler.generateResponse("0", "Datos Recuperados", HttpStatus.OK, lista);
	}

	/**
	 * Obtiene Reportes Asociados a una Categoria
	 * 
	 * @param ideCategoria identificador de la categoria
	 * @return Response con reportes asociados a la categoria
	 */
	@GetMapping("/{id}")
	@Operation(summary = "Servicio que permite recuperar los reportes asociados a una categoria")
	public ResponseEntity<Object> obtenerReporteCat(@PathVariable(name = "id", required = false) Integer ideCategoria) {
		log.info("Rest Adapter obtenerReporteCat");

		// Llamando el servicio de dominio obtenerMaestro, por identificador
		List<ReporteModel> reporteModel = domainQueryDrivingPort.obtenerReporteCat(ideCategoria);

		return ResponseHandler.generateResponse("0", "Datos Recuperados", HttpStatus.OK, reporteModel);
	}

	/**
	 * Asociar Reporte y Categoria
	 * 
	 * @param crearCategoriaReporteRequest cuerpo de la solicitud
	 * @return response con los detalles de la creación de la categoria
	 */

	@PostMapping("") 
	@Operation(summary = "Servicio que permite registrar la asociacion de reporte con categoria")
	public ResponseEntity<Object>
	crearReporte(@Valid @RequestBody ReporteRequestBody crearReporteRequest){
		log.info("Rest Adapter crearReporte");
		
		CategoriaModel categoriaModel = domainQueryDrivingPort.obtenerCategoria(crearReporteRequest.getIdeCategoria());
		String ideCategoria2 = categoriaModel.getNomCategoria();
		if (ideCategoria2.isEmpty()) {
			return ResponseHandler.generateResponse("99", "No existe Categoria", HttpStatus.BAD_REQUEST, categoriaModel);
		}

		List<ReporteModel> reporteModel = domainQueryDrivingPort.obtenerReporte(crearReporteRequest.getIdeReporte());
		if (!reporteModel.isEmpty()) {
			return ResponseHandler.generateResponse("99", "Reporte Ya asociado a Categoria", HttpStatus.BAD_REQUEST, categoriaModel);
		}
		Date date = new Date(System.currentTimeMillis());
		ReporteModel command = ReporteModel.builder()
				.ideReporte(crearReporteRequest.getIdeReporte())
				.ideCategoria(crearReporteRequest.getIdeCategoria())
				.codEstado("A")
				.fecCreacion(date)
				.usrCreacion(crearReporteRequest.getUsrCreacion())
				.fecBaja(null) 
				.usrBaja(null)
				.nomReporte(crearReporteRequest.getNomReporte())
				.build();

		//llamando al servicio de dominio crearCategoria return new
		return new ResponseEntity<>(domainCommandDrivingPort.crearReporte(command), HttpStatus.ACCEPTED);
	}


	/**
	 * Eliminar Registro Reporte asociado a 
	 * 
	 * @param ideReporte id del reporte a Eliminar
	 * @return responseEntity con status OK
	 */
	@DeleteMapping("/{id}")
	@Operation(summary = "Servicio que elimina la relacion de reporte y categoria")
	@Transactional("DbpbiTransactionManager")
	public ResponseEntity<Object> eliminarReporte(@PathVariable(name = "id", required = true) String ideReporte) {
		log.info("Rest Adapter eliminarReporte");

		List<ReporteModel> reporteModel = domainQueryDrivingPort.obtenerReporte(ideReporte);
		if (reporteModel.isEmpty()) {
			return ResponseHandler.generateResponse("99", "Reporte no se encuentra asociado", HttpStatus.BAD_REQUEST, reporteModel);
		}
		// llamando al servicio de dominio eliminarUsuario
		domainCommandDrivingPort.eliminarReporte(ideReporte);
		return ResponseHandler.generateResponse("0", "Datos Eliminados", HttpStatus.OK, reporteModel);
	}


	/**
	 * Modificar una Categoria
	 * 
	 * @param updateCategoriaRequestBody cuerpo de la solicitud
	 * @return response con los detalles de la modificacion de la categoria
	 */
	@Transactional("DbpbiTransactionManager")
	@PutMapping ("") 
	@Operation(summary = "Servicio que permite modificar la relación de reporte y categoria, dar de baja o activar")
	public ResponseEntity<Object>
	updateReporte(@Valid @RequestBody ReporteRequestBodyUpdate updateReporteRequestBody){
		log.info("Rest Adapter updateReporte");

		String salida=Utils.validaEntradaUpdateReporte(updateReporteRequestBody);

		log.info("salida {}", salida);
		Date date = new Date(System.currentTimeMillis());
		ReporteModel command = new ReporteModel();
		if (salida=="0") { 
			command = ReporteModel.builder()
			.ideReporte(updateReporteRequestBody.getIdeReporte())
			.codEstado("A")
			.fecBaja(null)
			.usrBaja(null)
			.build();
		}
		else if (salida=="2"){			
			command = ReporteModel.builder()
			.ideReporte(updateReporteRequestBody.getIdeReporte())
			.codEstado("B")
			.fecBaja(date) 
			.usrBaja(updateReporteRequestBody.getUsrBaja()) 
			.build();
		}
		
		if (salida=="0" || salida=="2") {
			return new ResponseEntity<>(domainQueryDrivingPort.updateReporte(command), HttpStatus.ACCEPTED);
		}
		
		String mensajeValida=null;
		String valorValida=null;
		if (salida =="1") {
			List<ReporteModel> reporteModel = domainQueryDrivingPort.obtenerReporte(updateReporteRequestBody.getIdeReporte());
			if (reporteModel.isEmpty()) {
				mensajeValida="Reporte No esta Asociado";
				valorValida=updateReporteRequestBody.getIdeReporte();
			}
			CategoriaModel categoriaModel = domainQueryDrivingPort.obtenerCategoria(updateReporteRequestBody.getIdeCategoria());
			String ideCategoria2 = categoriaModel.getNomCategoria();
			if (ideCategoria2.isEmpty()) {
				mensajeValida="No existe Categoria";
				valorValida=updateReporteRequestBody.getIdeCategoria().toString();				
			}
			if (reporteModel.get(0).getIdeCategoria() == updateReporteRequestBody.getIdeCategoria()) {
				mensajeValida="Reporte Asociado a Categoría ";
				valorValida=updateReporteRequestBody.getIdeCategoria().toString();				
			}
			if (mensajeValida==null) {
				domainCommandDrivingPort.eliminarReporte(updateReporteRequestBody.getIdeReporte());
				command = ReporteModel.builder()
						.ideReporte(updateReporteRequestBody.getIdeReporte())
						.ideCategoria(updateReporteRequestBody.getIdeCategoria())
						.codEstado(reporteModel.get(0).getCodEstado())
						.fecCreacion(reporteModel.get(0).getFecCreacion())
						.usrCreacion(reporteModel.get(0).getUsrCreacion())
						.fecBaja(reporteModel.get(0).getFecBaja()) 
						.usrBaja(reporteModel.get(0).getUsrBaja())
						.nomReporte(reporteModel.get(0).getNomReporte())
						.build();
				return new ResponseEntity<>(domainCommandDrivingPort.crearReporte(command), HttpStatus.ACCEPTED);
			}
		}
		return ResponseHandler.generateResponse("99", mensajeValida, HttpStatus.BAD_REQUEST, valorValida);
	}
}
