package cl.banchile.reportes.powerbi.application.adapters.in.rest;

import java.util.List;
import java.util.stream.Collectors;
import java.sql.Date;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import cl.banchile.reportes.powerbi.application.adapters.in.rest.model.UsuarioRequestBody;
import cl.banchile.reportes.powerbi.application.adapters.in.rest.model.UsuarioResponseBody;
import cl.banchile.reportes.powerbi.application.adapters.out.events.ResponseHandler;
import cl.banchile.reportes.powerbi.domain.model.domain.UsuarioModel;
import cl.banchile.reportes.powerbi.domain.model.to.CrearResourceResponse;
import cl.banchile.reportes.powerbi.domain.ports.in.DomainCommandPort;
import cl.banchile.reportes.powerbi.domain.ports.in.DomainQueryPort;
import io.swagger.v3.oas.annotations.Operation;
import lombok.extern.slf4j.Slf4j;

/**
 * Clase de implementación de Adaptador Rest Rest Controller
 */
@Slf4j
@RestController
// Raiz de URI Rest controller concide con lineamientos de arquitectura
// se considera en nombre del contexto, la versión y el dominio del servicio
@RequestMapping(path = "/${archetype.context-name}/${archetype.current-version}/${archetype.domain-name}/usuarios")
/*
 * @OpenAPIDefinition( info = @Info( title =
 * "Banchile Dominio Maestro Rest API", version = "1" ) )
 */
	public class UsuariosController {
	private DomainCommandPort domainCommandDrivingPort;
	private DomainQueryPort domainQueryDrivingPort;

	/**
	 * Constructor con inyección de dependencias
	 * 
	 * @param domainCommandDrivingPort puerto de comandos al dominio
	 * @param domainQueryDrivingPort   puerto de consultas al dominio
	 */
	public UsuariosController(@Autowired DomainCommandPort domainCommandDrivingPort,
			@Autowired DomainQueryPort domainQueryDrivingPort) {
		this.domainCommandDrivingPort = domainCommandDrivingPort;
		this.domainQueryDrivingPort = domainQueryDrivingPort;
	}

	/**
	 * obtener una lista de los Usuarios registrados
	 * 
	 * @return lista con los usuarios registrados
	 */
	@GetMapping("")
	@Operation(summary = "Servicio que permite listar los usuarios registrados")
	public ResponseEntity<Object> obtenerUsuarios() {
		log.info("Rest Adapter obtener Usuarios");

		// Llamando al servicio de dominio obtenerUsuarios
		List<UsuarioResponseBody> lista = domainQueryDrivingPort.obtenerUsuarios().stream()
				.map(usuarioModel -> UsuarioResponseBody.builder().ideUsuario(usuarioModel.getIdeUsuario())
						.nomUsuario(usuarioModel.getNomUsuario()).codEstado(usuarioModel.getCodEstado())
						.fecCreacion(usuarioModel.getFecCreacion()).usrCreacion(usuarioModel.getUsrCreacion())
						.fecBaja(usuarioModel.getFecBaja()).usrBaja(usuarioModel.getUsrBaja()).build())
				.collect(Collectors.toList());
		return ResponseHandler.generateResponse("0", "Datos Recuperados", HttpStatus.OK, lista);
	}

	/**
	 * Obtiene un Usuario, identificado por su id
	 * 
	 * @param ideUsuario identificador del Usuario
	 * @return Response con el Usuario
	 */
	@GetMapping("/{id}")
	@Operation(summary = "Servicio que permite recuperar usuario por id")
	public ResponseEntity<Object> obtenerUsuario(@PathVariable(name = "id", required = false) String ideUsuario) {
		log.info("Rest Adapter obtenerUsuario");

		// Llamando el servicio de dominio obtenerMaestro, por identificador
		UsuarioModel usuarioModel = domainQueryDrivingPort.obtenerUsuario(ideUsuario);

		return ResponseHandler.generateResponse("0", "Datos Recuperados", HttpStatus.OK, usuarioModel);
	}

	/**
	 * Crear un Usuario
	 * 
	 * @param crearUsuarioRequest cuerpo de la solicitud
	 * @return response con los detalles de la creación del recurso
	 */
	@PostMapping("")
	@Operation(summary = "Servicio que permite registrar un nuevo usuario")
	public ResponseEntity<CrearResourceResponse> crearUsuario(
			@Valid @RequestBody UsuarioRequestBody crearUsuarioRequest) {
		log.info("Rest Adapter crearUsuario");
		Date date = new Date(System.currentTimeMillis());
		UsuarioModel command = UsuarioModel.builder()
				.ideUsuario(crearUsuarioRequest.getIdeUsuario()).nomUsuario(crearUsuarioRequest.getNomUsuario())
				.codEstado("A").fecCreacion(date).usrCreacion(crearUsuarioRequest.getUsrCreacion()).fecBaja(null)
				.usrBaja(null).build();

		// llamando al servicio de dominio crearUsuario
		return new ResponseEntity<>(domainCommandDrivingPort.crearUsuario(command), HttpStatus.ACCEPTED);
	}


	/**
	 * Eliminar un Usuario, junto a todos sus detalles
	 * 
	 * @param ideUsuario id del Usuario a eliminar
	 * @return responseEntity con status OK
	 */
	@DeleteMapping("/{id}")
	@Operation(summary = "Servicio que permite eliminar un usuario ")
	public ResponseEntity<Object> eliminarUsuario(@PathVariable(name = "id", required = true) String ideUsuario) {
		log.info("Rest Adapter eliminarUsuario");

		UsuarioModel usuarioModel = domainQueryDrivingPort.obtenerUsuario(ideUsuario);
		String ideUsuario2 = usuarioModel.getIdeUsuario();
		if (ideUsuario2.isEmpty()) {
			return ResponseHandler.generateResponse("99", "Datos No Encontrados", HttpStatus.BAD_REQUEST, usuarioModel);
		}
		// llamando al servicio de dominio eliminarUsuario
		domainCommandDrivingPort.eliminarUsuario(ideUsuario);
		return ResponseHandler.generateResponse("0", "Datos Eliminados", HttpStatus.OK, usuarioModel);
	}

}