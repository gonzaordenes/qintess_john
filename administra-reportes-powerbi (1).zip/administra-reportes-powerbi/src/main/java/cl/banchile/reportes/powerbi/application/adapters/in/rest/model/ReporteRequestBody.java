package cl.banchile.reportes.powerbi.application.adapters.in.rest.model;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.Range;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Cuerpo del mensaje para la creación de maestro.
 * aplica al rest controller y modelo el request body de la solicitud http.
 * Se incluyenm anotaciones de validación a sewr controladas
 * con el Bean Validation Framework
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class ReporteRequestBody {

	//Validación de input. no puede ser nulo ni blanco
    @NotBlank(message = "ideReporte es mandatorio")
    private String ideReporte;
    
    //Validación de input. no puede ser nulo ni blanco
    @Range(min = 1)
    @NotNull(message= "ideCategoria mandatorio")
    private Integer ideCategoria;
    
    
    //Validación de input. no puede ser nulo ni blanco
    @NotBlank(message = "usrCreacion es mandatorio")
    private String usrCreacion;

    //Validación de input. no puede ser nulo ni blanco
    @NotBlank(message = "nomReporte es mandatorio")
    private String nomReporte;

    
}