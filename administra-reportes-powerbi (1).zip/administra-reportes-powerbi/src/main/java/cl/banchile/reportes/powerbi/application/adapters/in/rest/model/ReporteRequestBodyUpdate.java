package cl.banchile.reportes.powerbi.application.adapters.in.rest.model;

import javax.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Cuerpo del mensaje para la creación de maestro.
 * aplica al rest controller y modelo el request body de la solicitud http.
 * Se incluyenm anotaciones de validación a sewr controladas
 * con el Bean Validation Framework
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class ReporteRequestBodyUpdate {

	@NotBlank(message = "IdeReporte es Mandatorio")
	private String ideReporte;

    private Integer ideCategoria;

    private String usrBaja;

}