package cl.banchile.reportes.powerbi.application.adapters.in.rest.model;

import java.sql.Date;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Cuerpo del mensaje de respuesta a una solicitud de Usuario desde rest Adapter
 * Lombok para la omisión de código redundante
 * Implementa patrón builder
 * Getters, setters, equals y hashcode con @Data
 * Constructor con y sin argumentos
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class UsuarioResponseBody {
    private String ideUsuario;
    private String nomUsuario;
    private String codEstado;
    private Date  fecCreacion;
    private String usrCreacion;
    private Date  fecBaja;
    private String usrBaja;
}
