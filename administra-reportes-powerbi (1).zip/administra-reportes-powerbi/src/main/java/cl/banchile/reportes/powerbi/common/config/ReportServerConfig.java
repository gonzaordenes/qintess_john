package cl.banchile.reportes.powerbi.common.config;

import java.util.HashMap;
import java.util.Map;
import javax.sql.DataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.core.env.Environment;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

@Configuration
@EnableTransactionManagement
@EnableJpaRepositories(entityManagerFactoryRef = "ReportServerEntityManagerFactory",
    transactionManagerRef = "ReportServerTransactionManager",
    basePackages = { "cl.banchile.reportes.powerbi.application.adapters.out.jpa.reportserver" })
public class ReportServerConfig {

    @Autowired
    private Environment env;

    @Bean(name = "ReportServerDataSource")
    public DataSource reportServerDataSource() {
        final DriverManagerDataSource dataSource = new DriverManagerDataSource();
        dataSource.setUrl(this.env.getProperty("spring.ReportServer.datasource.url"));
        dataSource.setUsername(this.env.getProperty("spring.ReportServer.datasource.username"));
        dataSource.setPassword(this.env.getProperty("spring.ReportServer.datasource.password"));
        dataSource.setDriverClassName(this.env.getProperty("spring.ReportServer.datasource.driver-class-name"));
        return dataSource;
    }

    @Primary
    @Bean(name = "ReportServerEntityManagerFactory")
    public LocalContainerEntityManagerFactoryBean entityManagerFactory() {
        final LocalContainerEntityManagerFactoryBean em = new LocalContainerEntityManagerFactoryBean();
        em.setDataSource(this.reportServerDataSource());
        em.setPackagesToScan("cl.banchile.reportes.powerbi.application.adapters.out.jpa.reportserver.model");

        final HibernateJpaVendorAdapter vendorAdapter = new HibernateJpaVendorAdapter();
        em.setJpaVendorAdapter(vendorAdapter);

        final Map<String, Object> properties = new HashMap<>();
        properties.put("hibernate.hbm2ddl.auto", this.env.getProperty("spring.ReportServer.jpa.hibernate.ddl-auto"));
        properties.put("hibernate.show-sql", this.env.getProperty("spring.ReportServer.jpa.show-sql"));
        properties.put("hibernate.dialect", this.env.getProperty("spring.ReportServer.jpa.database-platform"));

        em.setJpaPropertyMap(properties);
        em.setPersistenceUnitName("ReportServerDataSource");
        return em;
    }

    @Primary
    @Bean(name = "ReportServerTransactionManager")
    public PlatformTransactionManager transactionManager() {
        final JpaTransactionManager transactionManager = new JpaTransactionManager();
        transactionManager.setEntityManagerFactory(this.entityManagerFactory().getObject());

        return transactionManager;
    }

}
