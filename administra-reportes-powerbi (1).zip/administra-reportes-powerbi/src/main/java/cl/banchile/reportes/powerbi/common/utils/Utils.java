package cl.banchile.reportes.powerbi.common.utils;

import cl.banchile.reportes.powerbi.application.adapters.in.rest.model.ReporteRequestBodyUpdate;

public final class Utils {
	
	private Utils() {
	    throw new IllegalStateException("Utility class");
	  }
	
	public static String validaEntradaUpdateReporte(ReporteRequestBodyUpdate reporteRequestBodyUpdate) {
		String response = null;
		if ((reporteRequestBodyUpdate.getIdeCategoria())==null && (reporteRequestBodyUpdate.getUsrBaja())==null)
		{
			response ="0"; 
		}
		else if ((reporteRequestBodyUpdate.getIdeCategoria())!=null && ((reporteRequestBodyUpdate.getUsrBaja())==null))
		{
			response ="1"; 
		}
		else if ((reporteRequestBodyUpdate.getIdeCategoria())==null && ((reporteRequestBodyUpdate.getUsrBaja())!=null))
		{
			response ="2"; 
		}
		
		return response;
	}

}



