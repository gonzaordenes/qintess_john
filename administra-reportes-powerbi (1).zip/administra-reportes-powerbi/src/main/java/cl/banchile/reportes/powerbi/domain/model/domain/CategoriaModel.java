package cl.banchile.reportes.powerbi.domain.model.domain;

import java.sql.Date;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Modelo de la entidad
 * de dominio Maestro 
 * Lombok para la omisión de código redundante
 * Implementa patrón builder
 * Getters, setters, equals y hashcode con @Data
 * Constructor con y con argumentos
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CategoriaModel {
	private Integer ideCategoria;
	private String nomCategoria;
    private String codEstado;
    private String codColor;
    private String codHobberColor;
    private String catImagen;
    private Date  fecCreacion;
    private String usrCreacion;
    private Date  fecBaja;
    private String usrBaja;
}
