package cl.banchile.reportes.powerbi.domain.model.domain;

import java.sql.Date;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Modelo de la entidad
 * de dominio Maestro 
 * Lombok para la omisión de código redundante
 * Implementa patrón builder
 * Getters, setters, equals y hashcode con @Data
 * Constructor con y con argumentos
 */

@Builder
@NoArgsConstructor
@AllArgsConstructor
@Data
public class ReporteModel {
	private String ideReporte;
	private Integer ideCategoria;
    private String codEstado;
    private Date  fecCreacion;
    private String usrCreacion;
    private Date  fecBaja;
    private String usrBaja;
    private String nomReporte;
}
