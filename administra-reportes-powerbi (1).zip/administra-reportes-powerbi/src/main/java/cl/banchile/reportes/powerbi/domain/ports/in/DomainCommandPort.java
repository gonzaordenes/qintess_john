package cl.banchile.reportes.powerbi.domain.ports.in;

import cl.banchile.reportes.powerbi.domain.model.domain.CategoriaModel;
import cl.banchile.reportes.powerbi.domain.model.domain.ReporteModel;
import cl.banchile.reportes.powerbi.domain.model.domain.UsuarioModel;
import cl.banchile.reportes.powerbi.domain.model.to.CrearResourceResponse;

/**
 * Puerto de acceso a los comandos de servicio de dominio
 */
public interface DomainCommandPort {

    //USUARIOS
    /**
     * Crear recurso maestro en el dominio
     * @param crearMaestroCommandModel Modelo del comando CrearMaestro
     * @return modelo genérico de creación de recurso de dominio
     */
    CrearResourceResponse crearUsuario(UsuarioModel crearUsuarioCommandModel);

    /**
     * Eliminar maestro
     * @param idMaestro identificador del maestro
     */
    void eliminarUsuario(String ideUsuario );

    //Categorias
    /**
     * Crear recurso categoria en el dominio
     * @param crearMaestroCommandModel Modelo del comando CrearMaestro
     * @return modelo genérico de creación de recurso de dominio
     */
    CrearResourceResponse crearCategoria(CategoriaModel crearCategoriaCommandModel);

    /**
     * Eliminar maestro
     * @param idMaestro identificador del maestro
     */
    void eliminarCategoria(Integer ideCategoria );

    //Reportes

	CrearResourceResponse crearReporte(ReporteModel crearReporteCommandModel);

	void eliminarReporte(String ideReporte);
  
    

}