package cl.banchile.reportes.powerbi.domain.ports.in;

import java.util.List;

import cl.banchile.reportes.powerbi.domain.model.domain.CategoriaModel;
import cl.banchile.reportes.powerbi.domain.model.domain.ReporteModel;
import cl.banchile.reportes.powerbi.domain.model.domain.UsuarioModel;
import cl.banchile.reportes.powerbi.domain.model.to.CrearResourceResponse;

/**
 * Puerto de acceso a consultas al servicio de dominio
 */
public interface DomainQueryPort {
	
    /**
     * Obtiene la lista de Usuarios registradoe en el dominio
     * @return lista con entidad de dominio Usuarios
     */
    List<UsuarioModel> obtenerUsuarios();

    /**
     * Obtiene un único Usuario, identificado por id
     * @param idMaestro identificador del recurso Usuarios
     * @return modelo de dominio de Usuarios
     */
    UsuarioModel obtenerUsuario(String idUsuario);
        
    
    /**
     * Obtiene la lista de Categoria registradoe en el dominio
     * @return lista con entidad de dominio maestros
     */
    List<CategoriaModel> obtenerCategorias();

    /**
     * Obtiene un único Maestro, identificado por id
     * @param idMaestro identificador del recurso Maestro
     * @return modelo de dominio de Maestro
     */
    CategoriaModel obtenerCategoria(Integer ideCategoria);

	void eliminarCategoria(Integer ideCategoria);

	CrearResourceResponse updateCategoria(CategoriaModel categoriaCommandModel);

	/**
     * Obtiene la lista de Categoria registradoe en el dominio
     * @return lista con entidad de dominio maestros
     */
    List<ReporteModel> obtenerReportes();

    /**
     * Obtiene un único Maestro, identificado por id
     * @param idMaestro identificador del recurso Maestro
     * @return modelo de dominio de Maestro
     */
	List<ReporteModel> obtenerReporteCat(Integer ideCategoria);


	List<ReporteModel> obtenerReporte(String idReporte);

	CrearResourceResponse updateReporte(ReporteModel crearReporteCommandModel);

	    
}