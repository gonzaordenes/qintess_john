package cl.banchile.reportes.powerbi.domain.ports.in;

import cl.banchile.reportes.powerbi.domain.model.domain.CatalogModel;
import java.util.List;

/**
 * Puerto de acceso a consultas al servicio de dominio
 */
public interface DomainQueryPortReports {

    List<CatalogModel> obtenerCatalogos();

    List<CatalogModel> obtenerCatalog();

    List<CatalogModel> obtenerCatalogUser(String user);

}
