package cl.banchile.reportes.powerbi.domain.service;

import cl.banchile.reportes.powerbi.common.exception.ResourceNotFoundException;
import cl.banchile.reportes.powerbi.domain.model.domain.CategoriaModel;
import cl.banchile.reportes.powerbi.domain.model.domain.ReporteModel;
import cl.banchile.reportes.powerbi.domain.model.domain.UsuarioModel;
import cl.banchile.reportes.powerbi.domain.model.to.CrearResourceResponse;
import cl.banchile.reportes.powerbi.domain.ports.in.DomainCommandPort;
import cl.banchile.reportes.powerbi.domain.ports.in.DomainQueryPort;
import cl.banchile.reportes.powerbi.domain.ports.out.DatabasePort;
import java.time.LocalDateTime;
import java.util.List;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

/**
 * implementación de Servicio de dominio
 * servicios con lógica de negocio
 * comunicación con el mundo externo es a través de puertos
 */
@Service
@Slf4j
public class DomainService implements DomainCommandPort, DomainQueryPort {

    private final DatabasePort databasePort;

    /**
     * Constructor con inyección de dependencia
     *
     * @param databasePort puerto de base de datos
     */
    public DomainService(
                         @Qualifier("jpaDao") final DatabasePort databasePort) {
        this.databasePort = databasePort;
    }

    /**
     * Obtener lista de maestros
     * persistidos en el dominio
     */
    /////////////////////////////////////////////////////////////
    // USUARIOS
    /////////////////////////////////////////////////////////////
    @Override
    public List<UsuarioModel> obtenerUsuarios() {
        return this.databasePort.getAllUsuarios();
    }

    @Override
    public UsuarioModel obtenerUsuario(final String idUsuario) {
        DomainService.log.info("Service obtenerUsuario");

        return this.databasePort.getUsuarioById(idUsuario)
            .orElseThrow(() -> new ResourceNotFoundException(String
                .format("Usuario con ID %s no encontrado", idUsuario)));
    }

    @Override
    public CrearResourceResponse crearUsuario(final UsuarioModel crearUsuarioCommandModel) {
        DomainService.log.info("Service crearUsuario");

        final UsuarioModel usuarioModel = this.databasePort.insertUsuario(UsuarioModel.builder()
            .ideUsuario(crearUsuarioCommandModel.getIdeUsuario())
            .nomUsuario(crearUsuarioCommandModel.getNomUsuario())
            .codEstado(crearUsuarioCommandModel.getCodEstado())
            .fecCreacion(crearUsuarioCommandModel.getFecCreacion())
            .usrCreacion(crearUsuarioCommandModel.getUsrCreacion())
            .fecBaja(crearUsuarioCommandModel.getFecBaja())
            .usrBaja(crearUsuarioCommandModel.getUsrBaja())
            .build());

        return CrearResourceResponse.builder()
            .id(usuarioModel.getIdeUsuario())
            .fechaCreacion(LocalDateTime.now())
            .build();

    }

    @Override
    public void eliminarUsuario(final String ideUsuario) {
        DomainService.log.info("Service eliminarUsuario");
        this.databasePort.deleteUsuario(ideUsuario);

    }

    /////////////////////////////////////////////////////////////
    // Categorias
    /////////////////////////////////////////////////////////////
    @Override
    public List<CategoriaModel> obtenerCategorias() {
        return this.databasePort.getAllCategorias();

    }

    @Override
    public CategoriaModel obtenerCategoria(final Integer idCategoria) {
        DomainService.log.info("Service obtenerCategoria");

        return this.databasePort.getCategoriaById(idCategoria)
            .orElseThrow(() -> new ResourceNotFoundException(String
                .format("Categoria con ID %s no encontrado", idCategoria)));
    }

    @Override
    public CrearResourceResponse crearCategoria(final CategoriaModel crearCategoriaCommandModel) {
        DomainService.log.info("Service crearCategoria");

        final CategoriaModel categoriaModel = this.databasePort.insertCategoria(CategoriaModel.builder()
            .nomCategoria(crearCategoriaCommandModel.getNomCategoria())
            .codEstado(crearCategoriaCommandModel.getCodEstado())
            .codColor(crearCategoriaCommandModel.getCodColor())
            .codHobberColor(crearCategoriaCommandModel.getCodHobberColor())
            .catImagen(crearCategoriaCommandModel.getCatImagen())
            .fecCreacion(crearCategoriaCommandModel.getFecCreacion())
            .usrCreacion(crearCategoriaCommandModel.getUsrCreacion())
            .fecBaja(crearCategoriaCommandModel.getFecBaja())
            .usrBaja(crearCategoriaCommandModel.getUsrBaja())
            .build());

        return CrearResourceResponse.builder()
            .id(categoriaModel.getNomCategoria())
            .fechaCreacion(LocalDateTime.now())
            .build();

    }

    @Override
    public void eliminarCategoria(final Integer ideCategoria) {
        DomainService.log.info("Service eliminarCategoria");
        this.databasePort.deleteCategoria(ideCategoria);

    }

    @Override
    public CrearResourceResponse updateCategoria(final CategoriaModel crearCategoriaCommandModel) {
        DomainService.log.info("Service actualizarCategoria");

        final CategoriaModel categoriaModel = this.databasePort.updateCategoria(CategoriaModel.builder()
            .ideCategoria(crearCategoriaCommandModel.getIdeCategoria())
            .nomCategoria(crearCategoriaCommandModel.getNomCategoria())
            .codEstado(crearCategoriaCommandModel.getCodEstado())
            .codColor(crearCategoriaCommandModel.getCodColor())
            .codHobberColor(crearCategoriaCommandModel.getCodHobberColor())
            .catImagen(crearCategoriaCommandModel.getCatImagen())
            .fecCreacion(crearCategoriaCommandModel.getFecCreacion())
            .usrCreacion(crearCategoriaCommandModel.getUsrCreacion())
            .fecBaja(crearCategoriaCommandModel.getFecBaja())
            .usrBaja(crearCategoriaCommandModel.getUsrBaja())
            .build());

        return CrearResourceResponse.builder()
            .id(categoriaModel.getIdeCategoria().toString())
            .fechaCreacion(LocalDateTime.now())
            .build();

    }

    /////////////////////////////////////////////////////////////
    // Reportes
    /////////////////////////////////////////////////////////////
    @Override
    public List<ReporteModel> obtenerReportes() {
        return this.databasePort.getAllReportes();
    }

    @Override
    public List<ReporteModel> obtenerReporteCat(final Integer idCategoria) {
        DomainService.log.info("Service obtenerReporteCat");

        return this.databasePort.getReporteCatById(idCategoria);
    }

    @Override
    public List<ReporteModel> obtenerReporte(final String idReporte) {
        DomainService.log.info("Service obtenerReporteCat");

        return this.databasePort.getReporteById(idReporte);
    }

    @Override
    public CrearResourceResponse crearReporte(final ReporteModel crearReporteCommandModel) {
        DomainService.log.info("Service crearReporte");

        final ReporteModel reporteModel = this.databasePort.insertReporte(ReporteModel.builder()
            .ideReporte(crearReporteCommandModel.getIdeReporte())
            .ideCategoria(crearReporteCommandModel.getIdeCategoria())
            .codEstado(crearReporteCommandModel.getCodEstado())
            .fecCreacion(crearReporteCommandModel.getFecCreacion())
            .usrCreacion(crearReporteCommandModel.getUsrCreacion())
            .fecBaja(crearReporteCommandModel.getFecBaja())
            .usrBaja(crearReporteCommandModel.getUsrBaja())
            .nomReporte(crearReporteCommandModel.getNomReporte())
            .build());

        return CrearResourceResponse.builder()
            .id(reporteModel.getIdeReporte())
            .fechaCreacion(LocalDateTime.now())
            .build();

    }

    @Override
    public void eliminarReporte(final String ideReporte) {
        DomainService.log.info("Service eliminarReporte");
        this.databasePort.deleteReporte(ideReporte);

    }

    @Override
    public CrearResourceResponse updateReporte(final ReporteModel crearReporteCommandModel) {
        DomainService.log.info("Service actualizarReporte");

        final ReporteModel reporteModel = this.databasePort.updateReporte(ReporteModel.builder()
            .ideReporte(crearReporteCommandModel.getIdeReporte())
            .ideCategoria(crearReporteCommandModel.getIdeCategoria())
            .codEstado(crearReporteCommandModel.getCodEstado())
            .fecCreacion(crearReporteCommandModel.getFecCreacion())
            .usrCreacion(crearReporteCommandModel.getUsrCreacion())
            .fecBaja(crearReporteCommandModel.getFecBaja())
            .usrBaja(crearReporteCommandModel.getUsrBaja())
            .nomReporte(crearReporteCommandModel.getNomReporte())
            .build());

        return CrearResourceResponse.builder()
            .id(reporteModel.getIdeReporte())
            .fechaCreacion(LocalDateTime.now())
            .build();

    }

}
