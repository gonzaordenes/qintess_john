package cl.banchile.reportes.powerbi.domain.service;

import cl.banchile.reportes.powerbi.domain.model.domain.CatalogModel;
import cl.banchile.reportes.powerbi.domain.ports.in.DomainQueryPortReports;
import cl.banchile.reportes.powerbi.domain.ports.out.DatabasePortReportServer;
import java.util.List;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

/**
 * implementación de Servicio de dominio
 * servicios con lógica de negocio
 * comunicación con el mundo externo es a través de puertos
 */
@Service

public class DomainServiceReports implements DomainQueryPortReports {

    private final DatabasePortReportServer databasePort;

    /**
     * Constructor con inyección de dependencia
     *
     * @param databasePort puerto de base de datos
     */
    public DomainServiceReports(
                                @Qualifier("jpaDao") final DatabasePortReportServer databasePort) {
        this.databasePort = databasePort;
    }

    @Override
    public List<CatalogModel> obtenerCatalogos() {
        return this.databasePort.getAllCatalogs();
    }

    @Override
    public List<CatalogModel> obtenerCatalog() {
        return this.databasePort.getCatalogs();
    }

    @Override
    public List<CatalogModel> obtenerCatalogUser(final String user) {
        return this.databasePort.getUserCatalogs(user);
    }

}
