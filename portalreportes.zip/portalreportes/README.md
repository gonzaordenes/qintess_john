
# Arquetipo Banchile NodeJs + Express + Angular 13.0.1

[![Quality Gate Status](http://codequality.banchile.cl/api/project_badges/measure?project=arquitectura-software_arquetipos_angular_bch-front-angular13-archetype&metric=alert_status)](http://codequality.banchile.cl/dashboard?id=arquitectura-software_arquetipos_angular_bch-front-angular13-archetype)
[![Reliability Rating](http://codequality.banchile.cl/api/project_badges/measure?project=arquitectura-software_arquetipos_angular_bch-front-angular13-archetype&metric=reliability_rating)](http://codequality.banchile.cl/dashboard?id=arquitectura-software_arquetipos_angular_bch-front-angular13-archetype)
[![Security Rating](http://codequality.banchile.cl/api/project_badges/measure?project=arquitectura-software_arquetipos_angular_bch-front-angular13-archetype&metric=security_rating)](http://codequality.banchile.cl/dashboard?id=arquitectura-software_arquetipos_angular_bch-front-angular13-archetype)
[![Technical Debt](http://codequality.banchile.cl/api/project_badges/measure?project=arquitectura-software_arquetipos_angular_bch-front-angular13-archetype&metric=sqale_index)](http://codequality.banchile.cl/dashboard?id=arquitectura-software_arquetipos_angular_bch-front-angular13-archetype)
[![Vulnerabilities](http://codequality.banchile.cl/api/project_badges/measure?project=arquitectura-software_arquetipos_angular_bch-front-angular13-archetype&metric=vulnerabilities)](http://codequality.banchile.cl/dashboard?id=arquitectura-software_arquetipos_angular_bch-front-angular13-archetype)
 

El objetivo de este arquetipo es proveer una estructura estandarizada de desarrollo la cual incluye la mayor parte de configuraciones necesarias para facilitar el trabajo de los desarrolladores.

Esta estructura está basada en (y optimizada para) **NodeJS v14.20** y **Angular CLI v13.0.1** como un "monolito" con capas backend y front respectivamente, e incluye las siguientes características:

 - Integración con plataformas de autenticación y autorización por medio de Azure AD.
 - Estructura de componentes visuales y servicios Angular.
 - Llamadas securitizadas al middleware, desde el front.
 - Capa de acceso a datos, para ser utilizado como arquetipo "monolítico", sin la necesidad de llamar a una Servicios del Backend.

** La capa FRONT, debe ser extendida aplicando las características de desarrolladas por el equipo UX Banchile.

  
## Procedimiento para desarrollar y liberar

 1. Revisar el diseño de la solución con el arquitecto de software asignado.
 2. Solicitar en Jenkins la creación del repositorio de acuerdo a lo indicado por el arquitecto asignado.
 3. Solicitar a Centro Operaciones Seguridad TI (SOC) vía ticket de Mesa Digital, la creación de una VIP y el Nombre de dominio (DNS) acordado con el arquitecto asignado.
 4. Una vez definido el DNS, se debe solicitar el **registro de la aplicacion en Azure AD** según la guía en Confluence ([Guía - Registro de Aplicaciones en Azure AD (AAD)](https://confluence.bantcent.cl/pages/viewpage.action?pageId=48630944))
 5. Reunirse con equipo UX para ver el diseño del front.
  

## Documentación Confluence🚀
La documentación actualizada se puede consultar en el enlace Confluence ([Arquetipo Banchile Node + Express + Angular](https://confluence.bantcent.cl/pages/viewpage.action?pageId=48628206))


# Changelog

#### Version 1.0.0 - Release 01/01/2022
- Release inicial del arquetipo

#### Version 1.1.1 - Release 13/04/2022
- Preparación de arquetipo para liberación automática a traves de tarea Jenkins (WIP)
- Eliminación de environments.ts de desarrollo y laboratorio. Ahora existe un único script de compilación para liberación en ambientes: `ng build`. para compilación local, se continua utilizando `ng build --configuration=local`

#### Version 1.1.2 - Release 22/04/2022
- Corrección en biconfig.js para correcta ubicación del body parser que permite parseo de cuerpos de mensajes (post, put, etc.).
- Merge con nuevas definiciones de componentes gráficos de UX

#### Version 1.2.0 - Release 30/08/2022
- Incorporación de Winston para manejo de logs


# Changelog "administra-reportes-powerbi" alias "portalreportes"

#### Version 1.2.3 - Release 13/02/2023
- Mejoras en visualizacion de carrusel y ordenamiento de categorias por nombre

#### Version 1.2.2 - Release 30/01/2023
- Mejoras en gestion de permisos de usuario
- Mejoras en visualizacion de carrusel y ordenamiento de reportes

#### Version 1.2.1 - Release 14/12/2022
- Adecuaciones para compatibilidad con Arquetipo Banchile

#### Version 1.1.1 - Release 02/12/2022
- Release inicial y correcciones varias
