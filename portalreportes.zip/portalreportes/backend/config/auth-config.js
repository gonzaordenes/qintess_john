export const creds = {
  // Requried
  identityMetadata: 'https://login.microsoftonline.com/b5e40b8e-efaa-4ee0-9cd3-049231ecfb0c/v2.0/.well-known/openid-configuration',
  // Required

  clientID: '94922a50-72fa-4321-a850-2a026b7603d1',
  // Required
  // If you are using the common endpoint, you should either set `validateIssuer` to false, or provide a value for `issuer`.
  validateIssuer: false,

  // Required
  // Set to true if you use `function(req, token, done)` as the verify callback.
  // Set to false if you use `function(req, token)` as the verify callback.
  passReqToCallback: false,

  // Required if you are using common endpoint and setting `validateIssuer` to true.
  // For tenant-specific endpoint, this field is optional, we will use the issuer from the metadata by default.
  issuer: null,

  // Optional, default value is clientID
  audience: 'api://94922a50-72fa-4321-a850-2a026b7603d1',
  
  // Optional. Default value is false.
  // Set to true if you accept access_token whose `aud` claim contains multiple values.
  allowMultiAudiencesInToken: false,

  // Optional. 'error', 'warn' or 'info'
  loggingLevel:'info',

  //Disable logging sensible information
  loggingNoPII: true};
