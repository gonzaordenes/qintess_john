import bodyparser from 'body-parser';
import { StatusCodes } from 'http-status-codes';

import logger from './logger.js';

// Modulos custom
// Deben ser importados todos los módulos implementados
import portalreportesModule from '../modules/portalreportes/module.js';

// AzureAD bearer authentication
import passport from 'passport';
import { BearerStrategy as OIDCBearerStrategy } from 'passport-azure-ad';
import { creds } from './auth-config.js';

// Configuraciones generales app de express como parametro de la función
const biconfig = app => {
   //Passport Msal - inicializando componente
  const options = {
    identityMetadata: creds.identityMetadata,
    clientID: creds.clientID,
    validateIssuer: creds.validateIssuer,
    issuer: creds.issuer,
    passReqToCallback: creds.passReqToCallback,
    allowMultiAudiencesInToken: creds.allowMultiAudiencesInToken,
    audience: creds.audience,
    loggingLevel: creds.loggingLevel,
    loggingNoPII: creds.loggingNoPII
  };

  // Starts passport
  app.use(passport.initialize());

  const bearerStrategy = new OIDCBearerStrategy(
    options,
    function(token, done) {
      console.log("verifying token done: ", done);
      console.log("token: ", token);
        if (!token.oid) {
          done(new Error('OID no encontrado en token'));
        } else {
          logger.info('OID token encontrado');
          done(null, token);
        }
    });

  passport.use(bearerStrategy);

  logger.info('Todo el tráfico entrante, expuesto bajo .../powerbi/... Va a requerir autorización');
  // app.get('/:url(powerbi)/*', (req, res) => res.send('\n oauth-bearer:' + req.session + '\n'))

  // logger.info('sesion : ', passport.);


  // Todo el tráfico entrante, expuesto bajo .../powerbi/... Va a requerir autorización
  app.use('/:url(powerbi)/*', passport.authenticate(['oauth-bearer'],{session: false}));



  //Uso general de bodyParser
  app.use(bodyparser.json());
  app.use(
    bodyparser.urlencoded(
      {extended: true}));

  // inicializando módulos
  // Todos los componente debe ser registrado en esta sección
  logger.info('Iniciando configuración de componentes....');
  portalreportesModule(app);

  const env = process.env.NODE_ENV || 'development';
  app.locals.ENV = env;
  app.locals.ENV_DEVELOPMENT = env === 'development';

  // manejo de errores 404
  app.use((req, res, next) => {
    const err = new Error('404 Manejado: No Encontrada');
    err.status = StatusCodes.NOT_FOUND;
    next(err);
  });

  //Control global de errores y parseo a estructura común
  app.use( (err, req, res, next) => {
    const dateNow = new Date();
    const code = !!err.code ? err.code : 'GenericException';
    const status = !!err.status ? err.status : StatusCodes.INTERNAL_SERVER_ERROR;
    const errorObject = {
        code: code,
        status: status,
        instante : dateNow.toISOString(),
        message: err.stack?.split('\n')[0],
    };

    logger.error(`Error en ruta '${req.url}', ${err}` );
    res.status(errorObject.status).json(errorObject);
    next(err);
  });

  return app;
};


export default biconfig;
