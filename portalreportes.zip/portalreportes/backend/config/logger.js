import dotenv from 'dotenv';
dotenv.config({ path: '.env' });

import winston from 'winston';
//const io = require('@pm2/io')

// Niveles de traza
const levels = {
  error: 0,
  warn: 1,
  info: 2,
  http: 3,
  debug: 4,
}

// Formato
const format = winston.format.combine(
  winston.format.timestamp({ format: 'YYYY-MM-DD HH:mm:ss' }),
  winston.format.printf(
    info => `[${info.timestamp}] [${info.level}] ${info.message}`
  ),
)

// Create logger
const logger = winston.createLogger({
  level: process.env.LOG_LEVEL || 'debug',
  levels,
  format,
  //solo Transport Console, ya que los archivos son administrados por PM2
  transports: [new winston.transports.Console()]
})

export default logger;