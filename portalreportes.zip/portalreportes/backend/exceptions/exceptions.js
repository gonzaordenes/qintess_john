import { StatusCodes } from 'http-status-codes';

/**
 * Clase Default Exception
 * Excepción generica a ser tratada por el middleware
 * @author: ivasquez. 03-2020
 */
export class DefaultException extends Error {

  constructor(message) {
    if(message){
      super(message);
    }else{
      super('Error en la aplicacion');
    }
    this.code = 'DefaultException';
    this.status = StatusCodes.BAD_REQUEST;
  }
};
// Control y log de errores
// Puede detectar la ruta en que se produce el error
export const errorMiddleware = (error, req, res) => {
  let errorObject;
  if (typeof error.toJson === 'function') {
    errorObject = error.toJson();
  } else {
    errorObject = {
      message: error.message,
      status: error.status,
      path: error.path,
      name: error.name
    };
  }
  console.error(`Error en ruta '${req.url}', ${error.status}, ${error.message}`);
  res.status(errorObject.status).json(errorObject);
};

export default this;