import { Router } from 'express';
import { StatusCodes } from 'http-status-codes';
import biutils from '../../../utilitarios/utilitarios.js';
import logger from '../../../config/logger.js';

// import de los servicios backend que usa el modulo
import service from '../service/CatalogoService.js';

const router = Router();

/* ##### nombre del modulo|directorio|ruta  ##### */
const rutaModulo = 'Catalogo';

// Exportación por defecto, app express como parámetro
export default app => {

  logger.info('Inicializando controller "' + rutaModulo + '"');

  app.use('/powerbi/v1/reportes/', router);

  // CATALOGO
  //Recupera catalogos disponible para el usuario. Invocacion tipo dominio/usuario
  router.get(
    '/catalogos-usuario/:codigo/:subcodigo',
    biutils.promesaHandlerFactory(async (req, res) => {
      var codigo = req.params.codigo
      var subcodigo = req.params.subcodigo
      logger.info('[controller] /catalogos-usuario');
      //invocacion de servicio externo
      const authHeader = req.header('Authorization');
      logger.info('Auth Header: ' + authHeader);
      const respuestaService = await service.getCatalog(codigo, subcodigo);
      res.status(StatusCodes.OK).send(respuestaService);
    }));
  //Recupera todos los reportes disponible en ReportServer
  router.get(
    '/catalogos',
    biutils.promesaHandlerFactory(async (req, res) => {
      logger.info('[controller] /catalogos');
      //invocacion de servicio externo
      const authHeader = req.header('Authorization');
      logger.info('Auth Header: ' + authHeader);
      const respuestaService = await service.getCatalogs();
      res.status(StatusCodes.OK).send(respuestaService);
    }));
  //Recupera desde ReportServer solo los catalogos tipo 13 o 2
    router.get(
      '/catalogos-filtrados',
      biutils.promesaHandlerFactory(async (req, res) => {
        logger.info('[controller] /catalogos-filtrados');
        //invocacion de servicio externo
        const authHeader = req.header('Authorization');
        logger.info('Auth Header: ' + authHeader);
        const respuestaService = await service.filterCatalogs();
        res.status(StatusCodes.OK).send(respuestaService);
      }));
};
