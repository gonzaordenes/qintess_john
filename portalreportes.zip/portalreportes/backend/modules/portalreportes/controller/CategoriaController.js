import { Router } from 'express';
import { StatusCodes } from 'http-status-codes';
import biutils from '../../../utilitarios/utilitarios.js';
import logger from '../../../config/logger.js';

// import de los servicios backend que usa el modulo
import service from '../service/CategoriaService.js';

const router = Router();

/* ##### nombre del modulo|directorio|ruta  ##### */
const rutaModulo = 'Categoria';

// Exportación por defecto, app express como parámetro
export default app => {

  logger.info('Inicializando controller "' + rutaModulo + '"');

  app.use('/powerbi/v1/reportes/', router);

  // CATEGORIAS
  // Controlador para servicio de categorias que llama a otro 

//Servicio que permite listar todas las categorias dispnibles
  router.get(
    '/categorias',
    biutils.promesaHandlerFactory(async (req, res) => {
      logger.info('[controller] /categorias');
      //invocacion de servicio externo
      const authHeader = req.header('Authorization');
      logger.info('Auth Header: ' + authHeader);
      const respuestaService = await service.getCategories();
      res.status(StatusCodes.OK).send(respuestaService);
    }));

//Servicio que permite crear nueva categoria
  router.post(
    '/categorias',
    biutils.promesaHandlerFactory(async (req, res) => {
      logger.info('[controller] /categorias');
      //invocacion de servicios backend
      const respuestaService = await service.addCategory(
        req.body,
        req.header('Authorization'));

      res.status(StatusCodes.OK).send(respuestaService);
    }));

  //Servicio que permite recuperar categoria por id
  router.get(
    '/categorias/:uid',
    biutils.promesaHandlerFactory(async (req, res) => {
      var uid = req.params.uid;
      logger.info('[controller] /categorias');
      //invocacion de servicio externo
      const authHeader = req.header('Authorization');
      logger.info('Auth Header: ' + authHeader);
      const respuestaService = await service.getCategory(uid);
      res.status(StatusCodes.OK).send(respuestaService);
    }));

  //Servicio que permite eliminar categoria por id
  router.delete(
    '/categorias/:uid',
    biutils.promesaHandlerFactory(async (req, res) => {
      var uid = req.params.uid;
      logger.info('[controller] /categorias');
      //invocacion de servicio externo
      const authHeader = req.header('Authorization');
      logger.info('Auth Header: ' + authHeader);
      const respuestaService = await service.delCategory(uid);
      res.status(StatusCodes.OK).send(respuestaService);
    }));

  //Servicio que permite modificar datos de categoria
  router.put(
    '/categorias',
    biutils.promesaHandlerFactory(async (req, res) => {
      logger.info('[controller] /categorias');
      //invocacion de servicios backend
      const respuestaService = await service.updateCategory(
        req.body,
        req.header('Authorization'));

      res.status(StatusCodes.OK).send(respuestaService);
    }));

  //Servicio no identificado
  router.put(
    '/drop/category',
    biutils.promesaHandlerFactory(async (req, res) => {
      logger.info('[controller] /drop/category');
      //invocacion de servicios backend
      const respuestaService = await service.dropCategory(
        req.body,
        req.header('Authorization'));

      res.status(StatusCodes.OK).send(respuestaService);
    }));

};
