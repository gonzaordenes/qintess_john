import { Router } from 'express';
import { StatusCodes } from 'http-status-codes';
import biutils from '../../../utilitarios/utilitarios.js';
import logger from '../../../config/logger.js';

// import de los servicios backend que usa el modulo
import service from '../service/ReportService.js';

const router = Router();

/* ##### nombre del modulo|directorio|ruta  ##### */
const rutaModulo = 'Reportes';

// Exportación por defecto, app express como parámetro
export default app => {

  logger.info('Inicializando controller "' + rutaModulo + '"');

  app.use('/powerbi/v1/', router);


  // REPORTES
  //Servicio que permite listar todos los reportes
  router.get(
    '/reportes',
    biutils.promesaHandlerFactory(async (req, res) => {
      logger.info('[controller] /reportes');
      //invocacion de servicio externo
      const authHeader = req.header('Authorization');
      logger.info('Auth Header: ' + authHeader);
      const respuestaService = await service.getReportesCategorias();
      res.status(StatusCodes.OK).send(respuestaService);
    }));
  //Servicio que permite registrar la asociacion de reporte con categoria
  router.get(
    '/reportes/:uid',
    biutils.promesaHandlerFactory(async (req, res) => {
      var uid = req.params.uid
      logger.info('[controller] /reportes');
      //invocacion de servicio externo
      const authHeader = req.header('Authorization');
      logger.info('Auth Header: ' + authHeader);
      // if(typeof authHeader === "undefined"){
      //   res.status(StatusCodes.BAD_REQUEST).send('undefined');
      // }else{
        const respuestaService = await service.getReporte(uid);
        res.status(StatusCodes.OK).send(respuestaService);
    // }
    }));
  //Servicios que permiten registrar la asociacion de reporte con categoria
  router.post(
    '/reportes',
    biutils.promesaHandlerFactory(async (req, res) => {
      logger.info('[controller] /reportes');
      //invocacion de servicios backend
      const respuestaService = await service.asociateReport(
        req.body,
        req.header('Authorization'));

      res.status(StatusCodes.OK).send(respuestaService);
    }));
  //Servicio que elimina la relacion de reporte y categoria
  router.delete(
    '/reportes/:uid',
    biutils.promesaHandlerFactory(async (req, res) => {
      var uid = req.params.uid
      logger.info('[controller] /reportes');
      //invocacion de servicio externo
      const authHeader = req.header('Authorization');
      logger.info('Auth Header: ' + authHeader);
      const respuestaService = await service.delReporte(uid);
      res.status(StatusCodes.OK).send(respuestaService);
    }));
  //????
  router.put(
    '/drop/report',
    biutils.promesaHandlerFactory(async (req, res) => {
      logger.info('[controller] /drop/report');
      //invocacion de servicios backend
      const respuestaService = await service.dropReport(
        req.body,
        req.header('Authorization'));

      res.status(StatusCodes.OK).send(respuestaService);
    }));
  router.put(
    '/reportes',
    biutils.promesaHandlerFactory(async (req, res) => {
      logger.info('[controller] /category/report');
      //invocacion de servicios backend
      const respuestaService = await service.updateReport(
        req.body,
        req.header('Authorization'));

      res.status(StatusCodes.OK).send(respuestaService);
    }));
  router.put(
    '/activate/report',
    biutils.promesaHandlerFactory(async (req, res) => {
      logger.info('[controller] /activate/report');
      //invocacion de servicios backend
      const respuestaService = await service.activateReport(
        req.body,
        req.header('Authorization'));

      res.status(StatusCodes.OK).send(respuestaService);
    }));
};
