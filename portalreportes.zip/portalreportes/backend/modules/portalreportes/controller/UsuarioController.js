import { Router } from 'express';
import { StatusCodes } from 'http-status-codes';
import biutils from '../../../utilitarios/utilitarios.js';
import logger from '../../../config/logger.js';

// import de los servicios backend que usa el modulo
import service from '../service/UserService.js';

const router = Router();

/* ##### nombre del modulo|directorio|ruta  ##### */
const rutaModulo = 'Usuario';

// Exportación por defecto, app express como parámetro
export default app => {

  logger.info('Inicializando controller "' + rutaModulo + '"');

  app.use('/powerbi/v1/reportes/', router);

  //USUARIOS
  // Controlador para servicio de usuarios que llama a otro 
  //Servicio que permite listar los usuarios registrados
  router.get(
    '/usuarios',
    biutils.promesaHandlerFactory(async (req, res) => {
      logger.info('[controller] /usuarios');
      //invocacion de servicio externo
      const authHeader = req.header('Authorization');
      logger.info('Auth Header: ' + authHeader);
      const respuestaService = await service.getUsers();
      res.status(StatusCodes.OK).send(respuestaService);
    }));
  //Servicio que permite recuperar usuario por id
  router.get(
    '/usuarios/:mail',
    biutils.promesaHandlerFactory(async (req, res) => {
      var mail = req.params.mail;
      logger.info(' mail: ' , mail);
      logger.info(' req: ', req);
      logger.info('[controller] /usuarios');
      //invocacion de servicio externo
      const authHeader = req.header('Authorization');
      logger.info('Auth Header: ' + authHeader);
      const respuestaService = await service.getUser(mail);
      res.status(StatusCodes.OK).send(respuestaService);
    }));
  //Servicio que permite eliminar un usuario
  router.delete(
    '/usuarios/:mail',
    biutils.promesaHandlerFactory(async (req, res) => {
      var mail = req.params.mail;
      logger.info(mail);
      logger.info(req);
      logger.info('[controller] /usuarios');
      //invocacion de servicio externo
      const authHeader = req.header('Authorization');
      logger.info('Auth Header: ' + authHeader);
      const respuestaService = await service.delUser(mail);
      res.status(StatusCodes.OK).send(respuestaService);
    }));
  //Servicio que permiten registrar un nuevo usuario
  router.post(
    '/usuarios',
    biutils.promesaHandlerFactory(async (req, res) => {
      logger.info('[controller] /usuarios');
      //invocacion de servicios backend
      const respuestaService = await service.addUser(
        req.body,
        req.header('Authorization'));

      res.status(StatusCodes.OK).send(respuestaService);
    }));

};
