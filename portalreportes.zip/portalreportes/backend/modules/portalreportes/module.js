import CatalogoController from './controller/CatalogoController.js';
import CategoriaController from './controller/CategoriaController.js';
import ReporteController from './controller/ReporteController.js';
import UsuarioController from './controller/UsuarioController.js';
import logger from '../../config/logger.js';


// app express como parámetro de función flecha
// Raiz del módulo no debe ser modificada
const module = app => { 
  CatalogoController(app),
  CategoriaController(app),
  ReporteController(app),
  UsuarioController(app)
};

export default module;
