
import { DefaultException } from '../../../exceptions/exceptions.js';
import got, { RequestError } from 'got';
import { parse } from '@hapi/bourne';
import logger from '../../../config/logger.js';
import { response } from 'express';


/**
 * SERVICIOS EXTERNOS
 * Module service se encarga de hacer las llamas a los servicios externos
 */


//CATALOGOS
const getCatalogs = async () => {
  logger.debug('[service] getCatalogs');
  return got(
    `${process.env.ENDPOINT_SERVICE_REPORTES_API}/catalogos`,
    { method: 'GET' })
    .then(response => parse(response.body))
    .catch(error => {
      logger.error(`Error al llamar la URL: ${process.env.ENDPOINT_SERVICE_REPORTES_API}/catalogos`);
      logger.error(error);
      throw error;
    });
};
const getCatalog = async (codigo, subcodigo) => {
  logger.debug('[service] catalogos-usuario');
  return got(
    `${process.env.ENDPOINT_SERVICE_REPORTES_API}/catalogos-usuario/${codigo}/${subcodigo}`,
    { method: 'GET' })
    .then(response => parse(response.body))
    .catch(error => {
      logger.error(`Error al llamar la URL: ${process.env.ENDPOINT_SERVICE_REPORTES_API}/catalogos-usuario`);
      logger.error(error);
      throw error;
    });
};
const filterCatalogs = async () => {
  logger.debug('[service] catalogos-filtrados');
  return got(
    `${process.env.ENDPOINT_SERVICE_REPORTES_API}/catalogos-filtrados`,
    { method: 'GET' })
    .then(response => parse(response.body))
    .catch(error => {
      logger.error(`Error al llamar la URL: ${process.env.ENDPOINT_SERVICE_REPORTES_API}/catalogos-filtrados`);
      logger.error(error);
      throw error;
    });
};

export default {
  getCatalogs,
  getCatalog,
  filterCatalogs
};
