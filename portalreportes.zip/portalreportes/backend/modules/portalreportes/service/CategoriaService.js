
import { DefaultException } from '../../../exceptions/exceptions.js';
import got, { RequestError } from 'got';
import { parse } from '@hapi/bourne';
import logger from '../../../config/logger.js';
import { response } from 'express';


/**
 * SERVICIOS EXTERNOS
 * Module service se encarga de hacer las llamas a los servicios externos
 */

// LLama a la API Pública Categories, la que retorna las getCategories
//CATEGORIAS
const getCategories = async () => {
  logger.debug('[service] getCategories');
  return got(
    `${process.env.ENDPOINT_SERVICE_REPORTES_API}/categorias`,
    { method: 'GET' })
    .then(response => parse(response.body))
    .catch(error => {
      logger.error(`Error al llamar la URL: ${process.env.ENDPOINT_SERVICE_REPORTES_API}/categorias`);
      logger.error(error);
      throw error;
    });
};
const addCategory = async body => {
  logger.debug('[service] addCategory');
  logger.debug(`${process.env.ENDPOINT_SERVICE_REPORTES_API}/categorias`);
  return got.post(
    `${process.env.ENDPOINT_SERVICE_REPORTES_API}/categorias`,
    {
      json: body,
      headers: { 'custom-header': 'banchile' }
    })
    .then(response => parse(response.body))
    .catch(error => {
      logger.error(`Error al llamar la URL: ${process.env.ENDPOINT_SERVICE_REPORTES_API}/categorias`);
      logger.error('Error a crear la categoria' + error);
      throw new DefaultException(`Ocurrio un error al consultar el servicio`);
    });
};
const getCategory = async (uid) => {
  logger.debug('[service] categorias');
  return got(
    `${process.env.ENDPOINT_SERVICE_REPORTES_API}/categorias/${uid}`,
    { method: 'GET' })
    .then(response => parse(response.body))
    .catch(error => {
      logger.error(`Error al llamar la URL: ${process.env.ENDPOINT_SERVICE_REPORTES_API}/categorias`);
      logger.error(error);
      throw error;
    });
};
const delCategory = async (uid) => {
  logger.debug('[service] delCategory');
  return got(
    `${process.env.ENDPOINT_SERVICE_REPORTES_API}/categorias/${uid}`,
    { method: 'DELETE' })
    .then(response => parse(response.body))
    .catch(error => {
      logger.error(`Error al llamar la URL: ${process.env.ENDPOINT_SERVICE_REPORTES_API}/categorias`);
      logger.error(error);
      throw new DefaultException(`Ocurrio un error al consultar el servicio`);
    });
};
const updateCategory = async body => {
  logger.debug('[service] updateCategory');
  logger.debug(`${process.env.ENDPOINT_SERVICE_REPORTES_API}/categorias`);
  return got.put(
    `${process.env.ENDPOINT_SERVICE_REPORTES_API}/categorias`,
    {
      json: body,
      headers: { 'custom-header': 'banchile' }
    })
    .then(response => parse(response.body))
    .catch(error => {
      logger.error(`Error al llamar la URL: ${process.env.ENDPOINT_SERVICE_REPORTES_API}/categorias`);
      logger.error(error);
      throw new DefaultException(`Ocurrio un error al consultar el servicio`);
    });
};
const dropCategory = async body => {
  logger.debug('[service] categorias');
  logger.debug(`${process.env.ENDPOINT_SERVICE_REPORTES_API}/categorias`);
  return got.put(
    `${process.env.ENDPOINT_SERVICE_REPORTES_API}/categorias`,
    {
      json: body,
      headers: { 'custom-header': 'banchile' }
    })
    .then(response => parse(response.body))
    .catch(error => {
      logger.error(`Error al llamar la URL: ${process.env.ENDPOINT_SERVICE_REPORTES_API}/categorias`);
      logger.error(error);
      throw new DefaultException(`Ocurrio un error al consultar el servicio`);
    });
};


export default {
  getCategories,
  addCategory,
  getCategory,
  delCategory,
  updateCategory,
  dropCategory,
};
