
import { DefaultException } from '../../../exceptions/exceptions.js';
import got, { RequestError } from 'got';
import { parse } from '@hapi/bourne';
import logger from '../../../config/logger.js';
import { response } from 'express';


/**
 * SERVICIOS EXTERNOS
 * Module service se encarga de hacer las llamas a los servicios externos
 */



//REPORTES
const getReportesCategorias = async () => {
  logger.debug('[service] getReportesCategorias');
  return got(
    `${process.env.ENDPOINT_SERVICE_REPORTES_API}/`,
    { method: 'GET' })
    .then(response => parse(response.body))
    .catch(error => {
      logger.error(`Error al llamar la URL: ${process.env.ENDPOINT_SERVICE_REPORTES_API}/`);
      logger.error(error);
      throw error;
    });
};
const getReporte = async (uid) => {
  logger.debug('[service] getReporte');
  return got(
    `${process.env.ENDPOINT_SERVICE_REPORTES_API}/${uid}`,
    { method: 'GET' })
    .then(response => parse(response.body))
    .catch(error => {
      logger.error(`Error al llamar la URL: ${process.env.ENDPOINT_SERVICE_REPORTES_API}/`);
      logger.error(error);
      throw error;
    });
};
const asociateReport = async body => {
  logger.debug('[service] asociateReport');
  logger.debug(`${process.env.ENDPOINT_SERVICE_REPORTES_API}/`);
  return got.post(
    `${process.env.ENDPOINT_SERVICE_REPORTES_API}/`,
    {
      json: body,
      headers: { 'custom-header': 'banchile' }
    })
    .then(response => parse(response.body))
    .catch((err) => {
      logger.error(`Error al llamar la URL: ${process.env.ENDPOINT_SERVICE_REPORTES_API}/`);
      let json = JSON.parse(err.response.body);
      throw new DefaultException(json.message);
    });
};
const delReporte = async (uid) => {
  logger.debug('[service] delReporte');
  return got(
    `${process.env.ENDPOINT_SERVICE_REPORTES_API}/${uid}`,
    { method: 'DELETE' })
    .then(response => parse(response.body))
    .catch((error) => {
      logger.error(`Error al llamar la URL: ${process.env.ENDPOINT_SERVICE_REPORTES_API}/`);
      logger.error(error);
      throw new DefaultException(`Ocurrio un error al consultar el servicio`);
    });
};
const dropReport = async body => {
  logger.debug('[service] dropReport');
  logger.debug(`${process.env.ENDPOINT_SERVICE_REPORTES_API}/`);
  return got.put(
    `${process.env.ENDPOINT_SERVICE_REPORTES_API}/`,
    {
      json: body,
      headers: { 'custom-header': 'banchile' }
    })
    .then(response => parse(response.body))
    .catch(error => {
      logger.error(`Error al llamar la URL: ${process.env.ENDPOINT_SERVICE_REPORTES_API}/`);
      logger.error(error);
      throw new DefaultException(`Ocurrio un error al consultar el servicio`);
    });
};
const updateReport = async body => {
  logger.debug('[service] updateReport');
  logger.debug(`${process.env.ENDPOINT_SERVICE_REPORTES_API}/`);
  return got.put(
    `${process.env.ENDPOINT_SERVICE_REPORTES_API}/`,
    {
      json: body,
      headers: { 'custom-header': 'banchile' }
    })
    .then(response => parse(response.body))
    .catch(error => {
      logger.error(`Error al llamar la URL: ${process.env.ENDPOINT_SERVICE_REPORTES_API}/`);
      logger.error(error);
      throw new DefaultException(`Ocurrio un error al consultar el servicio`);
    });
};
const activateReport = async body => {
  logger.debug('[service] activateReport');
  logger.debug(`${process.env.ENDPOINT_SERVICE_REPORTES_API}/`);
  return got.put(
    `${process.env.ENDPOINT_SERVICE_REPORTES_API}/`,
    {
      json: body,
      headers: { 'custom-header': 'banchile' }
    })
    .then(response => parse(response.body))
    .catch(error => {
      logger.error(`Error al llamar la URL: ${process.env.ENDPOINT_SERVICE_REPORTES_API}/`);
      logger.error(error);
      throw new DefaultException();
    });
};

export default {

  getReportesCategorias,
  getReporte,
  asociateReport,
  delReporte,
  dropReport,
  updateReport,
  activateReport,
};
