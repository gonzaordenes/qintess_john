
import { DefaultException } from '../../../exceptions/exceptions.js';
import got, { RequestError } from 'got';
import { parse } from '@hapi/bourne';
import logger from '../../../config/logger.js';
import { response } from 'express';


/**
 * SERVICIOS EXTERNOS
 * Module service se encarga de hacer las llamas a los servicios externos
 */

//USUARIOS
// LLama a la API Pública Users, la que retorna los usuarios.
const getUsers = async () => {
  logger.debug('[service] getUsers');
  return got(
    `${process.env.ENDPOINT_SERVICE_REPORTES_API}/usuarios`,
    { method: 'GET' })
    .then(response => parse(response.body))
    .catch(error => {
      logger.error(`Error al llamar la URL: ${process.env.ENDPOINT_SERVICE_REPORTES_API}/usuarios`);
      logger.error(error);
      throw error;
    });
};

const getUser = async (mail) => {
  logger.debug('[service] getUser');
  logger.debug(`${process.env.ENDPOINT_SERVICE_REPORTES_API}/usuarios/${mail}`);
  return got(
    `${process.env.ENDPOINT_SERVICE_REPORTES_API}/usuarios/${mail}`,
    { method: 'GET' })
    .then(response => parse(response.body))
    .catch(error => {
      logger.error(`Error al llamar la URL: ${process.env.ENDPOINT_SERVICE_REPORTES_API}/usuarios`);
      logger.error(error);
      throw error;
    });
};

const delUser = async (mail) => {
  logger.debug('[service] getUser');
  logger.debug(`${process.env.ENDPOINT_SERVICE_REPORTES_API}/usuarios/${mail}`);
  return got(
    `${process.env.ENDPOINT_SERVICE_REPORTES_API}/usuarios/${mail}`,
    { method: 'DELETE' })
    .then(response => parse(response.body))
    .catch(error => {
      logger.error(`Error al llamar la URL: ${process.env.ENDPOINT_SERVICE_REPORTES_API}/usuarios`);
      logger.error(error);
      throw new DefaultException();
    });
};

const addUser = async body => {
  logger.debug('[service] addUser');
  logger.debug(`${process.env.ENDPOINT_SERVICE_REPORTES_API}/usuarios`);
  return got.post(
    `${process.env.ENDPOINT_SERVICE_REPORTES_API}/usuarios`,
    {
      json: body,
      headers: { 'custom-header': 'banchile' }
    })
    .then(response => parse(response.body))
    .catch(error => {
      logger.error(`Error al llamar la URL: ${process.env.ENDPOINT_SERVICE_REPORTES_API}/usuarios`);
      logger.error(error);
      throw new DefaultException();
    });
};

export default {

  getUsers,
  getUser,
  delUser,
  addUser,
};
