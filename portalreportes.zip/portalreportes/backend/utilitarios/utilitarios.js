
/**
 * Arrow function para el tratamiento de promesas
 * Se usa para tratar respuestas de servicios externos
 */
const promesaHandlerFactory = middleware => {
  return async (req, res, next) => {
    try {
      await middleware(req, res, next);
    } catch (err) {
      next(err);
    }
  };
};

export default {promesaHandlerFactory};
