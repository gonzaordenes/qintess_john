import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MsalGuard } from '@azure/msal-angular';
import { AdminCategoriesComponent } from './components/admin-categories/admin-categories.component';
import { CarouselComponent } from './components/carousel-home/carousel.component';
import { AdminPanelComponent } from './components/panel-admin/admin-panel.component';
import { ReportsByCategoryComponent } from './components/reports-by-categorie/reports-by-category.component';
import { AdminPortalComponent } from './navegacion/admin/admin-portal/admin-portal.component';
import { AuthComponent } from './navegacion/auth/auth/auth.component';
import { UserPortalComponent } from './navegacion/user/user-portal/user-portal.component';
import { WelcomeComponent } from './navegacion/welcome/welcome.component';
import { HomeComponent } from './navegacion/home/home.component';

const routes: Routes = [
  {
    path: '',
    component: WelcomeComponent,
    // Guard permite el ruteo solo cuando el usuario está logueado
    canActivate: [MsalGuard]
  },
  {
    path: 'auth',
    component: AuthComponent,
    // Guard permite el ruteo solo cuando el usuario está logueado
    canActivate: [MsalGuard]
  },
  {
    path:'usuario', component: UserPortalComponent,
    children: [
        { component: CarouselComponent, path:''},
        { component: ReportsByCategoryComponent, path: 'search'},
    ],
    // Guard permite el ruteo solo cuando el usuario está logueado
    canActivate: [MsalGuard]
  },
  {
    path:'admin', component: AdminPortalComponent,
    children: [
        { component: CarouselComponent, path:''},
        { component: ReportsByCategoryComponent, path:'reports'},
        { component: ReportsByCategoryComponent, path: 'search'},
        { component: AdminPanelComponent, path: 'panel-admin'},
        { component: AdminCategoriesComponent, path: 'admin-categories'},
    ],
    // Guard permite el ruteo solo cuando el usuario está logueado
    canActivate: [MsalGuard]
  }   
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
