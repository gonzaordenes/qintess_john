import { HTTP_INTERCEPTORS, HttpClientModule } from '@angular/common/http';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgModule } from '@angular/core';
import { MsalBroadcastService, MsalGuard, MsalGuardConfiguration, MsalInterceptor, MsalInterceptorConfiguration, MsalService, MSAL_GUARD_CONFIG, MSAL_INSTANCE, MSAL_INTERCEPTOR_CONFIG } from '@azure/msal-angular';
import { BrowserCacheLocation, InteractionType, IPublicClientApplication, LogLevel, PublicClientApplication } from '@azure/msal-browser';
import { environment } from '../environments/environment';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

import { MatInputModule } from '@angular/material/input';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatButtonModule } from '@angular/material/button';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatListModule } from '@angular/material/list';
import { MatMenuModule } from '@angular/material/menu';
import { MatCardModule } from '@angular/material/card';
import { MatIconModule } from '@angular/material/icon';
import { MatSidenavModule } from '@angular/material/sidenav';

//navegacion
import { SidenavComponent } from './navegacion/sidenav/sidenav.component';
import { ToolbarComponent } from './navegacion/toolbar/toolbar.component';
import {DeslogueadoComponent} from './navegacion/deslogueado/deslogueado.component';
import { ProfileComponent } from './navegacion/profile/profile.component';
import {ProfileService} from './navegacion/profile/profile.service';
import { WelcomeComponent } from './navegacion/welcome/welcome.component';

import { ServiceWorkerModule } from '@angular/service-worker';
import { AuthComponent } from './navegacion/auth/auth/auth.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { EjemploSidenavComponent } from './sidenavs/ejemplo-sidenav/ejemplo-sidenav.component';
import { HomeComponent } from './navegacion/home/home.component';

//Portal de Reportes
import { NgbCarouselModule } from '@ng-bootstrap/ng-bootstrap';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { CarouselShortComponent } from './components/carousel-short/carousel-short.component';
import { AdminCategoriesComponent } from './components/admin-categories/admin-categories.component';
import { CarouselComponent } from './components/carousel-home/carousel.component';
import { HeaderComponent } from './components/header/header.component';
import { ListAdminComponent } from './components/list-admin/list-admin.component';
import { ListSearchComponent } from './components/list-search/list-search.component';
import { NavbarComponent } from './components/navbar-admin/navbar.component';
import { NavbarUserComponent } from './components/navbar-user/navbar-user.component';
import { AdminPanelComponent } from './components/panel-admin/admin-panel.component';
import { ReportsByCategoryComponent } from './components/reports-by-categorie/reports-by-category.component';

import { CommonModule } from '@angular/common';
import { AdminPortalComponent } from './navegacion/admin/admin-portal/admin-portal.component';
import { UserPortalComponent } from './navegacion/user/user-portal/user-portal.component';

// ********** Configuraciones MSal *****************
// Remove this line to use Angular Universal
const isIE = window.navigator.userAgent.indexOf("MSIE ") > -1 || window.navigator.userAgent.indexOf("Trident/") > -1;
// In Memory storage for Token Data
let store = {};

export function loggerCallback(logLevel: LogLevel, message: string) {
  
}

export function MSALInstanceFactory(): IPublicClientApplication {
  return new PublicClientApplication({
    auth: {
      clientId: '94922a50-72fa-4321-a850-2a026b7603d1',
      authority: 'https://login.microsoftonline.com/b5e40b8e-efaa-4ee0-9cd3-049231ecfb0c',
      redirectUri: !!window.location.hostname ?
        `${window.location.protocol}//${window.location.hostname}:${window.location.port}`
        : environment.msal_redirect_url ,
      postLogoutRedirectUri: !!window.location.hostname ?
        `${window.location.protocol}//${window.location.hostname}:${window.location.port}`
        : environment.msal_redirect_url ,
    },
    cache: {
      cacheLocation: BrowserCacheLocation.SessionStorage,
      secureCookies: true,
      storeAuthStateInCookie: isIE, // set to true for IE 11. Remove this line to use Angular Universal
    },
    system: {
      loggerOptions: {
        loggerCallback,
        logLevel: LogLevel.Info,
        piiLoggingEnabled: false
      }
    }
  });
}

export function MSALInterceptorConfigFactory(): MsalInterceptorConfiguration {
  const protectedResourceMap = new Map<string, Array<string>>();
  protectedResourceMap.set('https://graph.microsoft.com/v1.0/me', ['user.read', 'openid', 'profile']);
  protectedResourceMap.set('https://graph.microsoft.com/v1.0/me/photo', ['user.read', 'openid', 'profile']);
  protectedResourceMap.set('https://graph.microsoft.com', ['user.read', 'openid', 'profile']);
  protectedResourceMap.set('/api', ['api://94922a50-72fa-4321-a850-2a026b7603d1/api-access','user.read', 'openid', 'profile']);

  return {
    interactionType: InteractionType.Redirect,
    protectedResourceMap
  };
}

export function MSALGuardConfigFactory(): MsalGuardConfiguration {
  return { 
    interactionType: InteractionType.Redirect,
    authRequest: {
      scopes: [
        'user.read'
      ]
    },
    loginFailedRoute: '/'
  };
}
// ********** FIN Configuraciones MSal *****************

@NgModule({
  declarations: [
    DeslogueadoComponent,
    SidenavComponent,
    ToolbarComponent,
    ProfileComponent,
    WelcomeComponent,
    AuthComponent,
    EjemploSidenavComponent,
    HomeComponent,

    AdminCategoriesComponent,
    CarouselComponent,
    CarouselShortComponent,
    HeaderComponent,
    ListAdminComponent,
    ListSearchComponent,
    NavbarComponent,
    NavbarUserComponent,
    AdminPanelComponent,
    ReportsByCategoryComponent,

    AdminPortalComponent,
    UserPortalComponent,
    AppComponent
  ],
  imports: [
    NgbCarouselModule,
    NgbModule,
    HttpClientModule,
    BrowserModule,
    CommonModule,
    BrowserAnimationsModule,
    MatButtonModule,
    MatToolbarModule,
    MatListModule,
    MatMenuModule,
    MatCardModule,
    MatIconModule,
    MatSidenavModule,
    MatMenuModule,
    MatFormFieldModule,
    MatInputModule,
    FormsModule,
    ReactiveFormsModule,
    ServiceWorkerModule.register('ngsw-worker.js', {
      enabled: environment.production,
      // Register the ServiceWorker as soon as the app is stable
      // or after 30 seconds (whichever comes first).
      registrationStrategy: 'registerWhenStable:30000'
    }),
    AppRoutingModule
  ],
  providers: [
    {
      provide: HTTP_INTERCEPTORS,
      useClass: MsalInterceptor,
      multi: true
    },
    {
      provide: MSAL_INSTANCE,
      useFactory: MSALInstanceFactory
    },
    {
      provide: MSAL_GUARD_CONFIG,
      useFactory: MSALGuardConfigFactory
    },
    {
      provide: MSAL_INTERCEPTOR_CONFIG,
      useFactory: MSALInterceptorConfigFactory
    },
    MsalService,
    MsalGuard,
    MsalBroadcastService,
    ProfileService,
  ],
  exports: [
    AdminCategoriesComponent,
    CarouselComponent,
    CarouselShortComponent,
    HeaderComponent,
    ListAdminComponent,
    ListSearchComponent,
    NavbarComponent,
    NavbarUserComponent,
    AdminPanelComponent,
    ReportsByCategoryComponent,
    AdminPortalComponent,
    UserPortalComponent,
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
