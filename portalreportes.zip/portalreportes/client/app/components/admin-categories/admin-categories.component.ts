import { Component, OnInit, ViewChild } from '@angular/core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { CatalogoDTOModel } from 'client/app/model/catalogoDTO.model';
import { categoriesDTO } from 'client/app/model/categoriesDTO.model';
import { reportDTO } from 'client/app/model/reportDTO.model';
import { ApiService } from 'client/app/services/api.service';
import { lastValueFrom } from 'rxjs';
import { FormGroup, FormBuilder, Validators  } from '@angular/forms';
import { CarouselShortComponent } from '../carousel-short/carousel-short.component';

@Component({
  selector: 'app-admin-categories',
  templateUrl: './admin-categories.component.html',
  styleUrls: ['./admin-categories.component.css']
})
export class AdminCategoriesComponent implements OnInit {

  @ViewChild(CarouselShortComponent) CarouselShortComponent!:CarouselShortComponent;
  @ViewChild('modalMensaje') modalMensaje: any;
  public reportsPage: Array<reportDTO[]> = new Array<reportDTO[]>();
  public categoriesReport: categoriesDTO[] = [];
  public catalogo: CatalogoDTOModel[] = new Array<CatalogoDTOModel>();
  public ItemsPorPagina: number = 5;
  public reportes: reportDTO[] = [];
  public allReports: reportDTO[] = [];
  public indexActual: number = 0;
  public isMostrarValImagen: boolean = false
  public reportAdd = {
    ideReporte: 0,
    ideCategoria: 0,
    nomReporte: '',
    usrCreacion: ''
  };
  public reportEdit = {
    ideReporte: 0,
    ideCategoria: 0,
    nomReporte: '',
    usrCreacion: ''
  };
  public search: string = '';
  public message: string = '';
  public categorieEdit: any = {};
  public categories: categoriesDTO[] = [];
  public arrayData: any = [];
  public categoriePage: Array<categoriesDTO[]> = new Array<categoriesDTO[]>();
  public categoriasPorSlide = 5;
  public addCategorieForm!: FormGroup;
  public isFormSubmitted = false;
  public submittedValue: any;
  public categorieDetails:categoriesDTO = { 
    nomCategoria: '', 
    codColor:'',
    codHobberColor: '#333333',
    catImagen: '', 
    usrCreacion:'desarrollo@prueba.com'
  };
  public RADIO_LIST = [
    {name:'colorCat1', value:'#333333', checked:false, background:'#333333'},
    {name:'colorCat2', value:'#58595b', checked:false, background:'#58595b'},
    {name:'colorCat3', value:'#898989', checked:false, background:'#898989'},
    {name:'colorCat4', value:'#b2b2b2', checked:false, background:'#b2b2b2'},
    {name:'colorCat5', value:'#00b0f5', checked:false, background:'#00b0f5'},
    {name:'colorCat6', value:'#00abd3', checked:false, background:'#00abd3'},
    {name:'colorCat7', value:'#008cad', checked:false, background:'#008cad'},
    {name:'colorCat8', value:'#25e6de', checked:false, background:'#25e6de'},
    {name:'colorCat9', value:'#2bccc0', checked:false, background:'#2bccc0'},
    {name:'colorCat10',value:'#2ca89c', checked:false, background:'#2ca89c'}
  ]

  constructor(
    private modalService: NgbModal,
    private fb:FormBuilder,
    private apiService: ApiService
    ) { }

  ngOnInit(): void {
    this.loadCategories();
    this.addCategorieForm = this.fb.group({
      nameCategorie: ['',[Validators.required, Validators.minLength(2), Validators.maxLength(40)]],
      paymentOptions: ['', [Validators.required]],
    });
  }

  public loadCategories() {
    lastValueFrom(this.apiService.obtenerCategories())
      .then(payload => {
        this.arrayData = payload
        let categories = this.arrayData.data;
        let index=0;
        this.ordenarCategoria(categories);
        this.categoriePage = new Array<categoriesDTO[]>();
        while(index<categories.length){
          this.categoriePage.push(categories.slice(index,index+this.categoriasPorSlide));
          index= index +this.categoriasPorSlide;
        }
        this.categories = this.categoriePage[0];
        this.indexActual = 0;
      })
      .catch(error => {
        console.error(error);
      });
  }

  private ordenarCategoria(categoria: Array<categoriesDTO>) {
    const objSort = Object.assign(categoria, {});
    objSort.sort((a, b) => { return a.nomCategoria.localeCompare(b.nomCategoria, 'es', { sensitivity: 'base' }); }); 
  }

  public setCategories(categories: categoriesDTO[], indexActual: number) {
    this.categories = categories;
    this.indexActual = indexActual;
  }

  public setIndexActual(page: number) {
    if (this.indexActual + page >= 0 && this.indexActual + page < this.categoriePage.length) {
      this.indexActual = this.indexActual + page;
      this.categories = this.categoriePage[this.indexActual];
    }
  }

  public captureFile(event:any) {
    const auxImage = (event.target as HTMLInputElement).files;
    if (auxImage != null){
      const imageArchive = auxImage[0];
      const sizeImage = imageArchive.size;
      if (sizeImage > 926000){
        alert('Imagen excede las dimensiones permitidas');
        this.close();
      }
      else { 
        this.isMostrarValImagen = false;
        var img = new Image();    
        const reader = new FileReader();
        reader.readAsDataURL(imageArchive);
        reader.onload = () => {
          img.onload = () => {
        };   
        this.categorieDetails.catImagen = String(reader.result);
          img.src = String(reader.result);
        };
      }
    }
  }

  public addCategorie(categoriesDTO: any) {
    if(this.categorieDetails.catImagen?.length == 0){
      this.isMostrarValImagen = true;
      return false;
    } else {
      this.isMostrarValImagen = false;
      this.apiService.addCategorie(this.categorieDetails)
      .subscribe((data:{}) => {
        this.categorieDetails = { nomCategoria: '', codColor:'',codHobberColor: '#333333',
        catImagen: '', usrCreacion:'desarrollo@prueba.com'};
        this.loadCategories();
        this.close();
        this.CarouselShortComponent.loadCategories();
      },
      (error: any)=> {
        this.message = 'No se logro agregar la categoria';
          this.openModalReportes( this.modalMensaje);
      }
      );
      this.isFormSubmitted = true;
      if (!this.addCategorieForm.valid) {
        this.submittedValue = undefined;
        return false;
      } else {
        this.submittedValue = this.RADIO_LIST.find(
          (rv) => rv.value === this.addCategorieForm.value['paymentOptions']
        );
        return true;
      }
    }
  }

  public deleteCategorie(idCategorie: string){
    this.apiService.deleteCategorie(idCategorie).subscribe((data:{}) => {
      this.loadCategories();
      this.CarouselShortComponent.loadCategories();
      },
      (error: any )=>{
        this.message = error + ", no se logro eliminar la categoria";
        this.openModalReportes( this.modalMensaje);
      }
      );
  }

  public updateCategorie(idCategorie: string, categoriesDTO: categoriesDTO) {
    this.apiService.updateCategories(this.categorieEdit.ideCategoria, this.categorieDetails).subscribe(data => {
      this.categorieDetails = { nomCategoria: '', codColor:'',codHobberColor: '#333333',
      catImagen: '', usrCreacion:'desarrollo@prueba.com'};
      this.loadCategories();
      this.close();
      this.CarouselShortComponent.loadCategories();
    },
    (error: any ) => {
        this.message = error + ", no se logro actualizar la categoria";
        this.openModalReportes( this.modalMensaje);
    });
    this.isFormSubmitted = true;
    if (!this.addCategorieForm.valid) {
      this.submittedValue = undefined;
      return false;
    } else {
      this.submittedValue = this.RADIO_LIST.find(
        (rv) => rv.value === this.addCategorieForm.value['paymentOptions']
      );
      return true;
    }
  }

  public openModal(content:any) {
    this.loadReports();
    this.modalService.open(content,
      {
        centered: true,
        scrollable: true,
        size: 'lg',
      });
  }

  public openModalReportes(content: any, editar?:any) {
    this.limpiar();
    this.loadCategoriesReport();
    this.loadCatalogo();
    this.modalService.open(content,
      {
        centered: true,
        scrollable: true,
        size: 'lg',
      });
    if (editar){
      this.reportEdit = editar;
    }
  }

  public limpiar() {
    this.reportEdit = {
      ideReporte: 0,
      ideCategoria: 0,
      nomReporte: '',
      usrCreacion: ''
    }
    this.reportAdd = {
      ideReporte: 0,
      ideCategoria: 0,
      nomReporte: '',
      usrCreacion: ''
    }
  }

  public openModalReportesDelete(content: any) {
    this.loadCategoriesReport(true);
    this.modalService.open(content,
      {
        centered: true,
        scrollable: true,
        size: 'lg',
      });
  }

  public loadReports() {
    lastValueFrom(this.apiService.obtenerReportes())
      .then((payload: any) => {
        this.allReports = payload.data;
        this.compaginaReportes(this.allReports);
      })
      .catch((error: any) => {
        console.error(error);
      });
  }

  public loadCatalogo() {
    this.catalogo = [];
    this.apiService.filterCatalogs()
      .subscribe((arg: any) => {        
        this.catalogo = arg.data;
        this.catalogo.forEach(function(data) {
          data.path = data.path?.split("/")[data.path?.split("/").length - 2];
        });
         if(this.catalogo.length > 0) {
          this.ordenar(this.catalogo);
        }
      });
  }

  private ordenar(catalogo: Array<CatalogoDTOModel>) {
    const objSort = Object.assign(catalogo, {});
    objSort.sort((a, b) => { return a.nombre.localeCompare(b.nombre, 'es', { sensitivity: 'base' }); }); 
  }

  public compaginaReportes(reportes: reportDTO[]) {
    this.reportsPage = new Array<reportDTO[]>();
    reportes.forEach((element: reportDTO) => {
      element.nomCategoria = this.getCategory(element.ideCategoria);
    });
    let index = 0;
    while (index < reportes.length) {
      this.reportsPage.push(reportes.slice(index, index + this.ItemsPorPagina));
      index = index + this.ItemsPorPagina;
    }
    this.reportes = this.reportsPage[0];
    this.indexActual = 0;
  }

  public getCategory(ideCategoria?: number) {
    if (ideCategoria != undefined) {
      let result = this.categoriesReport.filter((category: categoriesDTO) => Number(category.ideCategoria) == ideCategoria);
      return (result[0]) ? result[0].nomCategoria : '';
    } else {
      return '';
    }
  }

  public loadCategoriesReport(callReport?: boolean) {
    this.categoriesReport = [];
    lastValueFrom(this.apiService.obtenerCategories())
      .then((payload: any) => {
        this.categoriesReport = payload.data;
        if (callReport) {
          this.loadReports();
        }
      })
      .catch((error: any) => {
        console.error(error);
      });
  }

  public addReport() {
    let user= JSON.parse(String(sessionStorage.getItem('user')));
    this.reportAdd.usrCreacion = user.username.split('@')[0];
    const report = this.catalogo.filter(r => r.itemId == String(this.reportAdd.ideReporte));
    this.reportAdd.nomReporte = String(report[0].nombre);
    lastValueFrom(this.apiService.addReport(this.reportAdd))
      .then((payload: any) => {
        this.close();
      })
      .catch((error: any) => {
        this.message = error.error.message;
        this.openModalReportes( this.modalMensaje);
      });
  }

  public deleteReport(report: reportDTO) {
    lastValueFrom(this.apiService.deleteReport(report))
      .then((payload: any) => {
        this.loadReports();
      })
      .catch((error: any) => {
        this.message = 'No se logro eliminar el reporte';
        this.openModalReportes( this.modalMensaje);
      });
  }
  
  public setReportes(reportes: reportDTO[], indexActual: number) {
    this.reportes = reportes;
    this.indexActual = indexActual;
  }

  public setIndexActualReport(page: number) {
    if (this.indexActual + page >= 0 && this.indexActual + page < this.reportsPage.length) {
      this.indexActual = this.indexActual + page;
      this.reportes = this.reportsPage[this.indexActual];
    }
  }

  public buscar() {
    const reportsFiltrados = this.allReports.filter(r => r.nomReporte?.toLocaleLowerCase()?.includes(this.search.toLowerCase()));
    this.compaginaReportes(reportsFiltrados);
  }

  public close() {
    this.modalService.dismissAll();
  }

  public editReport() {
    let user= JSON.parse(String(sessionStorage.getItem('user')));
    this.reportEdit.usrCreacion = user.username.split('@')[0];
    this.reportEdit.nomReporte = this.catalogo.filter(data => data.itemId?.toString() == this.reportEdit.ideReporte.toString())[0].nombre;
    lastValueFrom(this.apiService.editReport(this.reportEdit))
      .then((payload: any) => {
        this.loadReports();
        this.close();
      })
      .catch((error: any) => {
        this.message = "No se logro editar el reporte";
        this.openModalReportes( this.modalMensaje);
      });
  }

  public openModalEdit(content:any, categorie?:categoriesDTO) {
    this.modalService.open(content,
      {
        centered: true,
        scrollable: true,
        size: 'lg',
      });
      this.categorieEdit = categorie;
      this.categorieDetails  = categorie != undefined ? categorie : new categoriesDTO();
  }

}

