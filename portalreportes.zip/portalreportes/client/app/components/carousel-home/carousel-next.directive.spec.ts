import { CarouselNextDirective } from './carousel-next.directive';

describe('CarouselNextDirective', () => {
  it('should create an instance', () => {
    const directive = new CarouselNextDirective();
    expect(directive).toBeTruthy();
  });
});
