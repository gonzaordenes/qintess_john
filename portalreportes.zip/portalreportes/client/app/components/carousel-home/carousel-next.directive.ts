import { Directive, ElementRef, HostListener } from '@angular/core';

@Directive({
  selector: '[appCarouselNext]'
})
export class CarouselNextDirective {

  constructor(private currentCard: ElementRef) { 
  }

  @HostListener('click')
  public nextFunc(){
    var nextCard = this.currentCard.nativeElement.parentElement.parentElement.children[0];
    var card = nextCard.getElementsByClassName("card");
    nextCard.append(card[0]);
  }

}
