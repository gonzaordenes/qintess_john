import { CarouselPrevDirective } from './carousel-prev.directive';

describe('CarouselPrevDirective', () => {
  it('should create an instance', () => {
    const directive = new CarouselPrevDirective();
    expect(directive).toBeTruthy();
  });
});
