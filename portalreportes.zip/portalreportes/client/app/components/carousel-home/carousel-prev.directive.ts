import { Directive, ElementRef, HostListener } from '@angular/core';

@Directive({
  selector: '[appCarouselPrev]'
})
export class CarouselPrevDirective {

  constructor(private currentCard: ElementRef) { }

  @HostListener('click')
  public prevFunc(){
    var nextCard = this.currentCard.nativeElement.parentElement.parentElement.children[0];
    var card = nextCard.getElementsByClassName("card");
    nextCard.prepend(card[card.length - 1]);
  }
}
