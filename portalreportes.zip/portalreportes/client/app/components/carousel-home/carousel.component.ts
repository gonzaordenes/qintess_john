import { Component, Input, OnInit } from '@angular/core';
import { lastValueFrom, Observable } from 'rxjs';
import { responseDTO } from 'client/app/model/responseDTO.model';
import { categoriesDTO } from 'client/app/model/categoriesDTO.model';
import { ApiService } from 'client/app/services/api.service';
import { Router } from '@angular/router';
import { CatalogoDTOModel } from 'client/app/model/catalogoDTO.model';
import { ProfileService } from 'client/app/navegacion/profile/profile.service';
import { BreakpointObserver, Breakpoints, BreakpointState } from '@angular/cdk/layout';

@Component({
  selector: 'app-carousel',
  templateUrl: './carousel.component.html',
  styleUrls: ['./carousel.component.css']
})
export class CarouselComponent implements OnInit {
  private isScreen: Observable<BreakpointState> = this.breakpointObserver.observe([Breakpoints.Handset, Breakpoints.HandsetLandscape, Breakpoints.HandsetPortrait, Breakpoints.Large, Breakpoints.Medium, Breakpoints.Small, Breakpoints.Tablet, Breakpoints.TabletLandscape, Breakpoints.TabletPortrait, Breakpoints.Web, Breakpoints.WebLandscape, Breakpoints.WebPortrait, Breakpoints.XLarge, Breakpoints.XSmall]);
  resolucion: number = 0;
  categoriasRow: Array<categoriesDTO[]> = new Array<categoriesDTO[]>();
  arrayData: any = [];
  catalogo: CatalogoDTOModel[]= new Array<CatalogoDTOModel>();
  constructor(
    private apiService: ApiService,
    private router: Router,
    private profile: ProfileService,
    public breakpointObserver: BreakpointObserver
    ) { 
      this.isScreen.subscribe((state: BreakpointState) => {
        this.resolucion = window.innerWidth;
      });
    }

  ngOnInit(): void {
    this.isScreen.subscribe((state: BreakpointState) => {
      this.resolucion = window.innerWidth;
    });
    this.loadCatalogo();
  }

  public loadCatalogo(){
    let user= JSON.parse(String(sessionStorage.getItem('user')));
    this.apiService.getCatalogoByCode("BANTCENT",user.username.split('@')[0])
      .subscribe((arg : any)=> {
        this.catalogo=arg.data;
        sessionStorage.setItem('catalogo',JSON.stringify(this.catalogo));
        this.loadCategories();
      });
  }

  public loadCategories() {
    lastValueFrom(this.apiService.obtenerCategories())
      .then((payload : any) => {
        let categoriasUsuario: string[] = [];
        this.catalogo.forEach((cat)=> categoriasUsuario.push(cat.categoria?String(cat.categoria):''));
        let categories = payload.data.filter(
            (category: categoriesDTO)=>{
              return categoriasUsuario.includes(String(category.ideCategoria));
            }
          );
        this.ordenar(categories);
        let index=0;
        while(index<categories.length){
          this.categoriasRow.push(categories.slice(index,index+5));
          index= index +5;
        }
      })
      .catch((error :any )=> {
        console.error(error);
      });
  }

  private ordenar(categoria: Array<categoriesDTO>) {
    const objSort = Object.assign(categoria, {});
    objSort.sort((a, b) => { return a.nomCategoria.localeCompare(b.nomCategoria, 'es', { sensitivity: 'base' }); }); 
  }

  public goListaReportes(categorie:categoriesDTO){
    sessionStorage.setItem('categorie',JSON.stringify(categorie));
    this.router.navigateByUrl(this.router.url + '/search');
  }
}
