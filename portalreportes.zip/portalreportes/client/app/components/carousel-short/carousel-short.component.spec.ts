import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CarouselShortComponent } from './carousel-short.component';

describe('CarouselAdminComponent', () => {
  let component: CarouselShortComponent;
  let fixture: ComponentFixture<CarouselShortComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CarouselShortComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CarouselShortComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
