import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { categoriesDTO } from 'client/app/model/categoriesDTO.model';
import { ApiService } from 'client/app/services/api.service';
import { lastValueFrom } from 'rxjs';
import { Router } from '@angular/router';
import { CatalogoDTOModel } from 'client/app/model/catalogoDTO.model';
@Component({
  selector: 'app-carousel-short',
  templateUrl: './carousel-short.component.html',
  styleUrls: ['./carousel-short.component.css']
})
export class CarouselShortComponent implements OnInit {

  public isAdmin: boolean = true;
  @Output() recharge = new EventEmitter<string>();
  public catalogo: CatalogoDTOModel[] = new Array<CatalogoDTOModel>();
  public urlUserType: string = '';
  public urlPage: string = '';
  public categoriasRow: Array<categoriesDTO[]> = new Array<categoriesDTO[]>();
  public arrayData: any = [];
  public categoriasPorSlide = 5;

  constructor(
    private apiService: ApiService,
    private router: Router,
  ) { }

  ngOnInit(): void {
    const url = this.router.url.split('/');
    this.urlUserType = url[1];
    this.urlPage = url[2];
    this.isAdmin = this.urlUserType == 'admin';
    this.loadCategories();
  }

  public loadCategories() {
    lastValueFrom(this.apiService.obtenerCategories())
      .then((payload: any) => {
        this.arrayData = payload
        let categories;
        if(this.isAdmin && (this.urlPage=='reports' || this.urlPage=='admin-categories')){
          categories = this.arrayData.data;
        } else {
          let categoriasUsuario: string[] = [];
          this.catalogo = JSON.parse(String(sessionStorage.getItem('catalogo'))) as Array<CatalogoDTOModel>;
          this.catalogo.forEach((cat) => categoriasUsuario.push(cat.categoria ? String(cat.categoria) : ''));
          categories = payload.data.filter(
            (category: categoriesDTO) => {
              return categoriasUsuario.includes(String(category.ideCategoria));
            }
          );
        }
        this.ordenar(categories);
        this.categoriasRow= new Array<categoriesDTO[]>();
        let index = 0;
        while (index < categories.length) {
          this.categoriasRow.push(categories.slice(index, index + this.categoriasPorSlide));
          index = index + this.categoriasPorSlide;
        }
      })
      .catch((error: any) => {
        console.error(error);
      });
  }

  private ordenar(categoria: Array<categoriesDTO>) {
    const objSort = Object.assign(categoria, {});
    objSort.sort((a, b) => { return a.nomCategoria.localeCompare(b.nomCategoria, 'es', { sensitivity: 'base' }); }); 
  }

  public goSearch(categorie:categoriesDTO){
    sessionStorage.setItem('categorie',JSON.stringify(categorie));
    if(this.urlPage=='admin-categories'){
      this.router.navigateByUrl('/'+this.urlUserType+'/reports');
    }else{
      if(this.urlPage=='search' || this.urlPage=='reports'){
        this.recharge.emit();
      } else{
        this.router.navigateByUrl('/'+this.urlUserType+'/search');
      }
    }
  }
}
