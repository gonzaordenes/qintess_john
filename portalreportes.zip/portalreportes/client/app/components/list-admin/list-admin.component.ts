import { Component, OnInit, Input, ViewChild } from '@angular/core';
import { lastValueFrom } from 'rxjs';
import { userDTO } from 'client/app/model/userDTO.model';
import { ApiService } from 'client/app/services/api.service';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';


@Component({
  selector: 'app-list-admin',
  templateUrl: './list-admin.component.html',
  styleUrls: ['./list-admin.component.css']
})
export class ListAdminComponent implements OnInit {
  
  @ViewChild('modalMensaje') modalMensaje: any;
  @Input() public elimina = false;
  public usuarios: userDTO[] = [];
  public arrayData: any = [];
  @Input() userPage: Array<userDTO[]> = new Array<userDTO[]>();
  public indexActual: number = 0;
  public ItemsPorPagina = 5;
  public message: string='';

  constructor(
    private apiService: ApiService,
    private modalService: NgbModal,
  ) { }

  ngOnInit(): void {
    this.loadUsers();
  }

  public loadUsers() {
    lastValueFrom(this.apiService.obtenerUsers())
      .then(payload => {
        this.userPage = new Array<userDTO[]>();
        this.arrayData = payload
        let usuarios = this.arrayData.data;
        let index = 0;
        while (index < usuarios.length) {
          this.userPage.push(usuarios.slice(index, index + this.ItemsPorPagina));
          index = index + this.ItemsPorPagina;
        }
        this.usuarios = this.userPage[0];
        this.indexActual = 0;
      })
      .catch(error => {
        console.error(error);
      });
  }

  public setUsuarios(usuarios: userDTO[], indexActual: number) {
    this.usuarios = usuarios;
    this.indexActual = indexActual;
  }

  public setIndexActual(page: number) {
    if (this.indexActual + page >= 0 && this.indexActual + page < this.userPage.length) {
      this.indexActual = this.indexActual + page;
      this.usuarios = this.userPage[this.indexActual];
    }
  }

  public deleteUser(idUsuario: string) {
    lastValueFrom(this.apiService.delUser(idUsuario))
      .then(payload => {
        this.loadUsers();
      })
      .catch(error => {
        console.error(error);
        this.message = 'No se logro eliminar al usuario';
        this.openModal( this.modalMensaje);
      });
  }

  public openModal(content:any) {
    this.modalService.open(content,
      {
        centered: true,
        scrollable: true,
        size: 'lg',
      });
  }
}
