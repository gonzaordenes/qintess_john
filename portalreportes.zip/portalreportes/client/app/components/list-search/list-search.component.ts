import { Component, OnInit, Input } from '@angular/core';
import { categoriesDTO } from 'client/app/model/categoriesDTO.model';
import { lastValueFrom } from 'rxjs';
import { ApiService } from 'client/app/services/api.service';
import { reportDTO } from 'client/app/model/reportDTO.model';
import { CatalogoDTOModel } from 'client/app/model/catalogoDTO.model';
import { Router } from '@angular/router';
import { CommunicationService } from '../../services/communication.service';

@Component({
  selector: 'app-list-search',
  templateUrl: './list-search.component.html',
  styleUrls: ['./list-search.component.css']
})
export class ListSearchComponent implements OnInit {
  
  public categorie: categoriesDTO=new categoriesDTO();
  public reportsPage: Array<reportDTO[]> = new Array<reportDTO[]>();
  public ItemsPorPagina: number=5;
  public indexActual: number=0;
  public reportes: reportDTO[] = [];
  public categories: categoriesDTO[] = [];
  public catalogo: CatalogoDTOModel[]= new Array<CatalogoDTOModel>();
  public urlUserType: string='';
  public urlPage: string='';
  public strBusqueda:string='';

  constructor(
    private apiService: ApiService,
    private router: Router,
    private communicationService: CommunicationService
  ) {
    
  }

  ngOnInit(): void {
    this.catalogo= JSON.parse(String(sessionStorage.getItem("catalogo"))) as CatalogoDTOModel[];
    let reportList= JSON.parse(String(sessionStorage.getItem("reportList"))) as reportDTO[];
    const url=this.router.url.split('/');
    this.urlUserType= url[1];
    this.urlPage= url[2];
    let cat= sessionStorage.getItem("categorie");
    if(cat!=null){
      this.loadCategories();
    }
    if(reportList!=null){
      sessionStorage.removeItem("reportList");
      this.loadCategories(reportList);
    }       
    this.communicationService.componentMethodCalled$.subscribe((busca) => {
      this.loadCategories(busca);
    });
    this.strBusqueda = "Resultado de búsqueda";
    let busqueda = sessionStorage.getItem("busqueda");
    if(busqueda != undefined) {
      if(busqueda.length > 0)
        this.strBusqueda = this.strBusqueda + ': "' + busqueda + '"';
    }
    this.communicationService.getBusqueda$.subscribe((dato) => {
      this.strBusqueda = "Resultado de búsqueda";
      if (dato.length > 0) {
        this.strBusqueda = this.strBusqueda + ': "' + dato + '"';
      }
    });
  }

  public loadReports() {    
    let cat= sessionStorage.getItem("categorie");
    this.categorie= JSON.parse(String(cat)) as categoriesDTO;
    lastValueFrom(this.apiService.obtenerReportebyId(String(this.categorie.ideCategoria)))
      .then((payload : any) => {
        let reportes = payload.data;
        reportes.forEach((element : reportDTO) => {
          this.getReport(element);
        });
        if(this.urlPage!='reports'){
          this.compaginaReportes(reportes.filter(d => d.url != ""));
        }else {
          this.compaginaReportes(reportes);
        }
      })
      .catch((error: any) => {
        console.error(error);
      });
  }

  public compaginaReportes(reportes:reportDTO[]){
    this.reportsPage=new Array<reportDTO[]>();
    reportes.forEach((element : reportDTO) => {
      element.nomCategoria= this.getCategory(element.ideCategoria);
    });
    let index=0;
    while(index< reportes.length){
      this.reportsPage.push(reportes.slice(index,index+this.ItemsPorPagina));
      index= index +this.ItemsPorPagina;
    }
    this.reportes = this.reportsPage[0];
    this.indexActual=0;
  }

  public setReportes(reportes: reportDTO [], indexActual: number){
    this.reportes=reportes;
    this.indexActual=indexActual;
  }

  public setIndexActual(page:number){
    if(this.indexActual + page>=0 && this.indexActual + page <this.reportsPage.length){
      this.indexActual=this.indexActual+page;
      this.reportes=this.reportsPage[this.indexActual];
    }
  }

  public loadCategories(buscador?: reportDTO[]) {
    lastValueFrom(this.apiService.obtenerCategories())
      .then((payload:any) => {
        this.categories = payload.data;        
        if(buscador!=undefined){
          this.compaginaReportes(buscador);
          this.categorie= new categoriesDTO();
        } else{
          this.loadReports();
        }
      })
      .catch((error:any) => {
        console.error(error);
      });
  }

  public getCategory(ideCategoria?: number){
    if(ideCategoria != undefined){
      let result = this.categories.filter((category : categoriesDTO)=> Number(category.ideCategoria)==ideCategoria);
      return (result[0])?result[0].nomCategoria:'';
    }else{
      return '';
    }
  }

  public getReport(reporte: reportDTO){
    const data=this.catalogo.filter((cat: CatalogoDTOModel)=>cat.categoria==reporte.ideCategoria && cat.nombre == reporte.nomReporte);
    if(data.length>0){
      reporte.url=data[0].path;
    } else {
      reporte.url = "";
    }
  }

  public seeReport(url?: string){
    if(url!=undefined){
      window.open(url);
    }
  }
}
