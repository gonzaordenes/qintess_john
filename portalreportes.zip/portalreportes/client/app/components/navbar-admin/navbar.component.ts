import { Component, OnInit } from '@angular/core';
import { ApiService } from 'client/app/services/api.service';
import { lastValueFrom } from 'rxjs';
import { CatalogoDTOModel } from 'client/app/model/catalogoDTO.model';
import { reportDTO } from 'client/app/model/reportDTO.model';
import { CommunicationService } from '../../services/communication.service';
import { Router } from '@angular/router';
import { HttpClient, HttpHeaders } from '@angular/common/http';

const GRAPH_REST_PHOTO = (clientId: any) => `https://graph.microsoft.com/beta/users/${clientId}/photo/$value`;
const GRAPH_ENDPOINT = 'https://graph.microsoft.com/v1.0/me';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})
export class NavbarComponent implements OnInit {
  buscador:string='';
  user: any;
  public profile: any;
  public imageToShow: any = null;
  public jobTitle: any = '';
  
  constructor(
    private apiService: ApiService,
    private communicationService: CommunicationService,
    private router: Router,
    private http: HttpClient
  ) { }

  ngOnInit(): void {
    this.user=  JSON.parse(String(sessionStorage.getItem('user')));
    lastValueFrom(this.http.get(GRAPH_ENDPOINT))
      .then((profile) => {
          this.profile = profile;
          this.getPhoto();
          this.jobTitle = this.profile.jobTitle;
      });
  }

  public getPhoto() {
    lastValueFrom( this.http.get(GRAPH_REST_PHOTO(
      this.profile.id
      ),{responseType: 'blob'}) )
      .then((photoBlob) => {
        let reader = new FileReader();
        reader.addEventListener("load", () => {
            this.imageToShow = reader.result;
        }, false);
        if (photoBlob) {
            reader.readAsDataURL(photoBlob);
        }
      })
      .catch( e => {
        console.error('NO SE PUEDE OBTENER IMAGEN: ' + e.message);
      });
  }

  public buscarReporte(){
    this.communicationService.addEvent(this.buscador);
    sessionStorage.setItem('busqueda', this.buscador);
    let reportList: Array<reportDTO> = new Array<reportDTO>();
    let catalogo=  JSON.parse(String(sessionStorage.getItem('catalogo'))) as Array<CatalogoDTOModel>;
    catalogo=catalogo.filter(
      (cat : CatalogoDTOModel)=>{        
        return cat.nombre?.toLowerCase().includes(this.buscador.toLowerCase());
      }
    );
    catalogo.forEach(
      (cat: CatalogoDTOModel)=>{
        let report=new reportDTO();
        report.nomReporte=cat.nombre;
        report.ideCategoria=cat.categoria;
        report.url=cat.path;
        reportList.push(report);
      }
    );
    sessionStorage.removeItem("categorie");
    sessionStorage.setItem('reportList',JSON.stringify(reportList));
    this.communicationService.callComponentMethod(reportList);
  }

  public goToHome(){
    this.router.navigate(['admin']);
  }
}
