import { Component, ViewChild } from '@angular/core';
import { NgbModal, ModalDismissReasons, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ApiService } from 'client/app/services/api.service';
import { lastValueFrom } from 'rxjs';
import { userDTO } from 'client/app/model/userDTO.model';
import { Router } from '@angular/router';
import { ListAdminComponent } from '../list-admin/list-admin.component';

@Component({
  selector: 'app-admin-panel',
  templateUrl: './admin-panel.component.html',
  styleUrls: ['./admin-panel.component.css']
})

export class AdminPanelComponent {
  @ViewChild('modalMensaje') modalMensaje: any;
  @ViewChild(ListAdminComponent, { static: false }) userPages!: ListAdminComponent;
  public elimina = false;
  public title = 'appBootstrap';
  public usuarioFormGroup!: FormGroup;
  public usuarioModalReference!: NgbModalRef;
  public resultPost: any;
  public isFormSubmitted = false;
  public message: string='';

  constructor(
    private modalService: NgbModal,
    private fb: FormBuilder,
    private apiService: ApiService,
    private router: Router
  ) { }

  ngOnInit() {
    this.usuarioFormGroup = this.fb.group({
      idUsuario: ['', [Validators.required, Validators.minLength(2), Validators.maxLength(40)]],
      nomUsuario: ['', [Validators.required, Validators.minLength(2), Validators.maxLength(40)]]
    });
  }

  public openAssign(content: any) {
    this.usuarioModalReference = this.modalService.open(content,
      {
        ariaLabelledBy: 'modal-assign',
        centered: true,
        scrollable: true,
        size: 'lg',
      });
  }

  public addUser(usuarioDTO: { idUsuario: string, nomUsuario: string }) {
    this.isFormSubmitted = true;
    if (!this.usuarioFormGroup.valid) {
      return false;
    } else {
      let newUser = new userDTO;
      newUser.ideUsuario = usuarioDTO.idUsuario;
      newUser.nomUsuario = usuarioDTO.nomUsuario;
      this.setUsuario(newUser);
      return true;
    }
  }

  public setUsuario(usuarioDTO: userDTO) {
    lastValueFrom(this.apiService.addUser(usuarioDTO))
      .then(payload => {
        this.resultPost = payload;
        this.userPages.ngOnInit();
        this.modalService.dismissAll();
      })
      .catch(error => {
        console.error(error);
        this.message = 'No se logro agregar al usuario';
        this.openModal( this.modalMensaje);
      });
  }

  public openModal(content: any) {
    this.modalService.open(content,
      {
        centered: true,
        scrollable: true,
        size: 'lg',
      });
  }

  public openDelete(content: any) {
    this.modalService.open(content,
      {
        ariaLabelledBy: 'modal-delete',
        centered: true,
        scrollable: true,
        size: 'lg',
      }).result.then(() => {
        this.userPages.userPage = new Array<userDTO[]>();
        this.userPages.ngOnInit();
      });
  }
}
