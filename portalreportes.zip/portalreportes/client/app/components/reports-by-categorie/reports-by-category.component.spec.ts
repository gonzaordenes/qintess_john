import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ReportsByCategoryComponent } from './reports-by-category.component';

describe('ReportsByCategoryComponent', () => {
  let component: ReportsByCategoryComponent;
  let fixture: ComponentFixture<ReportsByCategoryComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ReportsByCategoryComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ReportsByCategoryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
