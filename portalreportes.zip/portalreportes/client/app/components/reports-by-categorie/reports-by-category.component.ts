import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-reports-by-category',
  templateUrl: './reports-by-category.component.html',
  styleUrls: ['./reports-by-category.component.css']
})
export class ReportsByCategoryComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
