export interface CatalogoDTOModel {
  nombre:    string;
  categoria?: number;
  itemId?:    string;
  type?:      number;
  path:      string;
}
