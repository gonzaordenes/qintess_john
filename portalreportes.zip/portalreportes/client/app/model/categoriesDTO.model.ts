export class categoriesDTO {
    ideCategoria?: number;
    nomCategoria: string = '';
    codEstado?: string;
    codColor?: string;
    codHobberColor?: string;
    catImagen?: string;
    fecCreacion?: string;
    usrCreacion?: string;
    fecBaja?: string;
    usrBaja?: string;
}