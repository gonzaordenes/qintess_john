export class reportDTO {
  ideReporte?: string;
  ideCategoria?: number;
  nomCategoria?: string;
  codEstado?: string;
  fecCreacion?: string;
  usrCreacion?: string;
  fecBaja?: string;
  usrBaja?: string;
  nomReporte?: string;
  url?: string;

}
