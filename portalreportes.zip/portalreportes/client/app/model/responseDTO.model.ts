export class responseDTO {
    responseCode?: number;
    message?: string;
    data?: any;
    status?: any;
}