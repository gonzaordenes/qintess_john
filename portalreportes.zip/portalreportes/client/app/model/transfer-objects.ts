export class BoredActivityResponse {
    activity!: string;
    type!: string;
    participants!: number;
    price!: number;
    link!: string;
    key!: string;
    accessibility!: string;
};

export class PersonaDBModel {
    nombre!: string;
    rut!: string;
};