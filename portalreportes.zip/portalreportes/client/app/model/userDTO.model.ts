export class userDTO {
    ideUsuario?: string;
    nomUsuario?: string;
    codEstado?: string;
    fecCreacion?: string;
    usrCreacion?: string;
    fecBaja?: string;
    usrBaja?: string;
}