import { Component, OnInit } from '@angular/core';
import { FormControl } from '@angular/forms';
import { MsalService } from '@azure/msal-angular';
import { lastValueFrom } from 'rxjs';

@Component({
  selector: 'app-auth',
  templateUrl: './auth.component.html',
  styleUrls: ['./auth.component.scss']
})
export class AuthComponent implements OnInit {
  private accessTokenRequest = {
    scopes: ['user.read', 'openid', 'profile', 'api://0ec01772-3287-4c3b-96fb-18dd04b245ac/api-access']
  }

  public authTokenFormControl = new FormControl('');

  constructor(private authService: MsalService) { }

  ngOnInit() {
    lastValueFrom(this.authService.acquireTokenSilent(this.accessTokenRequest))
      .then( payload  => {
        this.authTokenFormControl.setValue(payload.idToken);
      })
      .catch((error) => {
        
      });
  }
}
