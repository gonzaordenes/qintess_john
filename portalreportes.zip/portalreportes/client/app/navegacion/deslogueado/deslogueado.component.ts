import { Component} from '@angular/core';
import { Observable} from 'rxjs';
import { AppComponent } from '../../app.component';
import { ProfileService } from '../profile/profile.service';

@Component({
  selector: 'app-deslogueado',
  templateUrl: './deslogueado.component.html',
  styleUrls: ['./deslogueado.component.css']
})
export class DeslogueadoComponent {
  public isLoggedIn$: Observable<boolean>;

  constructor(
      private profileService: ProfileService,
      private appComponent: AppComponent
  ) {
    this.isLoggedIn$ = this.profileService.execChange.asObservable();
  }


  public openLoginFlow(){
    this.appComponent.loginPopup();
  }

}
