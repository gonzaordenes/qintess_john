import { Component, OnInit } from '@angular/core';
import { CommunicationService } from 'client/app/services/communication.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {
  constructor(
    private communicationService: CommunicationService,
    private router: Router
  ) { 
  }

  ngOnInit(): void {
    this.communicationService.getRedirect$.subscribe((dato) => {
      if(sessionStorage.getItem('user')!=null)
      {
        let user = JSON.parse(String(sessionStorage.getItem('user'))) ;
        if(user.ideUsuario == undefined){
            this.router.navigate(['usuario']);
        }else{
            this.router.navigate(['admin']);
        }
      }
    });
  }
}
