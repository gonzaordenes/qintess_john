import { Component, OnInit, OnDestroy } from '@angular/core';

import { HttpClient } from '@angular/common/http';
import { lastValueFrom, Observable } from 'rxjs';
import {ProfileService} from './profile.service';
// push notifications
import {SwPush, SwUpdate} from '@angular/service-worker';
import { SpinnerOverlayService } from '../../services/spinner-overlay.service';
import { MsalService } from '@azure/msal-angular';
import { Router } from '@angular/router';

const GRAPH_ENDPOINT = 'https://graph.microsoft.com/v1.0/me';
const GRAPH_REST_PHOTO =  (clientId: any) => `https://graph.microsoft.com/v1.0/me/photo/$value`; 

@Component({
  selector: 'profile-component',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit, OnDestroy{
  title = 'Título de la App';

  today = new Date();


  public isLoggedIn$: Observable<boolean>;
  public isLoggedIn: boolean = false;
  // Imagen a mostrar en el front
  public imageToShow: any;

  //msal Account informnation
  public account: any;
  // MS Graph profile information
  public profile: any;

  constructor(
    private msalService: MsalService,
    private http: HttpClient,
    private profileService: ProfileService,
    private swPush: SwPush,
    private swUpdate: SwUpdate,
    private spinnerOverlayService: SpinnerOverlayService,
    public route: Router,
  ) {
    this.isLoggedIn$ = this.profileService.execChange.asObservable();
  }

  ngOnInit() {
    this.spinnerOverlayService.spin$.next(true);
    this.isLoggedIn$.subscribe({
      next: (logged: boolean) => {
        if(logged){
          this.isLoggedIn = true;
          this.account =this. msalService.instance.getActiveAccount();
          this.profileService.setAccount(this.account);

          lastValueFrom(this.http.get(GRAPH_ENDPOINT))
          .then((profile) => {
              this.profile = profile;
          })
          // activar si se requiere gatillar la suscripción de Web Push Notifications
          //.then(() => this.subscribeToNotifications())
          .then(() => this.getPhoto())
          .then(() => this.spinnerOverlayService.spin$.next(false));

        }
      },
      // Error
      error: (error: any) => {
        this.spinnerOverlayService.spin$.next(false);
      },
      // Complete
      complete: () => {
        this.spinnerOverlayService.spin$.next(false);
      }
    })

  }

  ngOnDestroy(){
    this.swPush.unsubscribe();
  }

  public login() {
    const isIE = window.navigator.userAgent.indexOf('MSIE ') > -1 || window.navigator.userAgent.indexOf('Trident/') > -1;

    if (isIE) {
      this.msalService.loginRedirect();
    } else {
      this.msalService.loginPopup();
    }
  }

  public logout() {
    this.msalService.logout();
  }


  private getPhoto() {
    lastValueFrom( this.http.get(GRAPH_REST_PHOTO(this.profile.id),{responseType: 'blob'}) )
      .then((photoBlob) => {
        let reader = new FileReader();
        reader.addEventListener("load", () => {
            this.imageToShow = reader.result;
        }, false);

        if (photoBlob) {
            reader.readAsDataURL(photoBlob);
        }
      })
      .catch( e => {
        console.error('NO SE PUEDE OBTENER IMAGEN: ' + e.message);
      });
  }

  // Solo activar se se requiere implementar suscripcion Web Push Notification
  // La lógica de persistencia de la suscripción debe ser manejada por el backend
  // private subscribeToNotifications() {
  //   if(this.swUpdate.isEnabled ) {
  //     this.swPush.requestSubscription({serverPublicKey: this.VAPID_PUBLIC_KEY})
  //       .then((sub) => {
  //         this.backendService.subscribeToNotification(sub, this.profile).toPromise()
  //           .then( () )
  //           .catch( (error) => {
  //             console.error('Error Subscription: ' + JSON.stringify(error));
  //           });
  //       })
  //     .catch((err) => console.error('Could not Subscribe to notifications: ' + JSON.stringify(err)) );
  //   } else {

  //   }
  // }

}