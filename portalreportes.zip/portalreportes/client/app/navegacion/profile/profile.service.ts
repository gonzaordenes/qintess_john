import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ProfileService {

  // siempre mantiene el ultimo estado de login en memoria
  public execChange: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(false);
  public account: any;

  constructor() {
    // Constructor vacío.
    // No es necesario inyectar componentes
  }

  public loginStatusChange(data: boolean) {
    this.execChange.next(data);
   // console.info('Modificando estatus del login a :' + data);
  }

  public setAccount(account: any){
    this.account = account;
  }

  public getName(): string{
    return this.account?.name;
  }

  public getUserName(): string{
    return this.account?.username.split('@')[0];
  }

  public getJobTitle(): string{
    return this.account?.jobTitle;
  }

}
