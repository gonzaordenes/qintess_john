import { Component, OnInit, OnDestroy } from '@angular/core';
import { trigger, transition, style, animate, state } from '@angular/animations';
import { Router } from '@angular/router';
import { Observable, Subscription } from 'rxjs';
import { ProfileService } from '../profile/profile.service';

@Component({
  selector: 'app-sidenav',
  templateUrl: './sidenav.component.html',
  animations: [
    trigger(
      'enterAnimation', [
        transition(':enter', [
          style({transform: 'translateX(-100%)', opacity: 0}),
          animate('300ms', style({transform: 'translateX(0)', opacity: 1}))
        ]),
        transition(':leave', [
          style({transform: 'translateX(0)', opacity: 1}),
          animate('500ms', style({transform: 'translateX(-100%)', opacity: 0}))
        ])
      ]
    ),
    trigger('animationMenu', [      
      transition(':enter', [
        style({transform: 'translateX(-100%)', opacity: 0}),
        animate('300ms', style({transform: 'translateX(0)', opacity: 1}))
      ]),
      transition(':leave', [
        style({transform: 'translateX(0)', opacity: 1}),
        animate('500ms', style({transform: 'translateX(-100%)', opacity: 0}))
      ]),
      state('*', style({ backgroundColor: '' })),
    ])
  ],
})
export class SidenavComponent implements OnInit,OnDestroy {

  public isLoggedIn$: Observable<boolean>;
  private isLogedInSubscription: Subscription | undefined;
  public isLoggedIn: boolean = false;

  public classApplied = false;
  public isMenuOpen = true;

  constructor(private router:Router,
              private profileService: ProfileService) {
    this.isLoggedIn$ = this.profileService.execChange.asObservable();
  }
  ngOnInit() {
    this.isLogedInSubscription = this.isLoggedIn$.subscribe(
      (next) => {
        this.isLoggedIn = next;
      }
    );
  }

  ngOnDestroy(): void {
    this.isLogedInSubscription?.unsubscribe();
  }

  toggleMenu(): void {
    this.isMenuOpen = !this.isMenuOpen;
    
  }

  toggleClass() {
    this.classApplied = !this.classApplied;
  }

}
