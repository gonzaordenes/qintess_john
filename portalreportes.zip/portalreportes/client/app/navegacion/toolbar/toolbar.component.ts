import { Component } from '@angular/core';
import { Observable } from 'rxjs';
import { ProfileService } from '../profile/profile.service';

@Component({
  selector: 'app-toolbar',
  templateUrl: './toolbar.component.html'
})
export class ToolbarComponent {

  public isLoggedIn$: Observable<boolean>;

  constructor(private profileService: ProfileService) {
    this.isLoggedIn$ = this.profileService.execChange.asObservable();
  }

}
