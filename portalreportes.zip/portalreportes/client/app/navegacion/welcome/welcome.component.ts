import { Component, OnInit, Input } from '@angular/core';
import {Router} from '@angular/router';
import { BoredActivityResponse, PersonaDBModel } from 'client/app/model/transfer-objects';
import { ApiService } from 'client/app/services/api.service';
import { SidenavsService } from 'client/app/services/sidenavs.service';
import { lastValueFrom } from 'rxjs';
import { ProfileService } from '../profile/profile.service';


@Component({
  selector: 'welcome-component',
  templateUrl: './welcome.component.html',
  styleUrls: ['./welcome.component.scss']
})
export class WelcomeComponent implements OnInit{

  public boredActivity!: BoredActivityResponse;

  public personaDB!: PersonaDBModel;

  pagina: any;

  @Input() loggedIn = false;
  constructor(
    private router: Router,
    public profileService: ProfileService,
    private apiService: ApiService,
    private sidenavsService: SidenavsService
  ) {
    
  }

  sidenavEjemplo() {
    this.pagina = 'sidenavEjemplo';
    this.sidenavsService.lanzarSidenav.emit({
      page: this.pagina
    })
  }

  ngOnInit(): void {
    // Se llama a servicio disponible en API, donde se llama a un servicio externo para obtener una actividad (Bored API)
    // lastValueFrom(this.apiService.obtenerBoredActivity())
    //   .then( payload => {
    //     this.boredActivity = payload
    //   })
    //   .catch(error => {
    //     console.error(error);
    //   });
  }

  public obtenerPersonaButtonClicked(event: any): void{
    // Se llama a servicio disponible en API, donde se extrae el user de usuario conectado y se obtiene su rut desde la base de datos (Oracle)
    // Esto permite implementación ágil de arquetipo al ser visto como un 'monolito'
    // lastValueFrom(this.apiService.obtenerPersonaFromDB(this.profileService.getUserName()))
    //   .then(payload => {
    //     this.personaDB = payload;
    //   })
    //   .catch(error => {
    //     console.error(error);
    //   });
  }

}
