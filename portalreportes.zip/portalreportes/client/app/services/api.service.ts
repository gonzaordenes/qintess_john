import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Logger } from '@azure/msal-browser';
import { environment } from 'client/environments/environment';
import { Observable, throwError } from 'rxjs';
import { retry, catchError } from 'rxjs/operators';
import { reportDTO } from '../model/reportDTO.model';
import { responseDTO } from '../model/responseDTO.model';
import { userDTO } from '../model/userDTO.model';
import { categoriesDTO } from '../model/categoriesDTO.model';
import { json } from 'express';

@Injectable({
  providedIn: 'root'
})
export class ApiService {
  //TODO : favor dejar en vacio para pasar de ambiente - http://localhost:8098
  SERVER_URL: string = 'http://localhost:8098';
  user:any;
  constructor(private http: HttpClient) { 
  }

  //CATEGORIAS
  //obtener todas las categorias
  public obtenerCategories(): Observable<responseDTO> {
    const url = `${this.SERVER_URL}/powerbi/v1/reportes/categorias`;
    return this.http
      .get<responseDTO>(url)
      .pipe(retry(1), catchError(this.errorHandl));
  }

  //Agregar categoria desde panel administrador
  public addCategorie(categorie: categoriesDTO): Observable<categoriesDTO> {
    const url = `${this.SERVER_URL}/powerbi/v1/reportes/categorias`;
    categorie.usrCreacion=this.getUsrCreacion();
    return this.http
      .post<categoriesDTO>(url,categorie)
      .pipe(retry(1), 
    catchError(this.errorHandl));
  }

  //Eliminar categoria desde panel administrador
  public deleteCategorie(id_categorie: string): Observable<categoriesDTO> {
    const url = `${this.SERVER_URL}/powerbi/v1/reportes/categorias`;
    return this.http
      .delete<categoriesDTO>(url + '/' + id_categorie)
      .pipe(retry(1), catchError(this.errorHandl));
  }

  //Editar categoria desde panel administrador
  public updateCategories(idCategoria: string, categorie: categoriesDTO): Observable<responseDTO> {
    const url = `${this.SERVER_URL}/powerbi/v1/reportes/categorias`;

    let body={
      "ideCategoria":Number(idCategoria),
      "nomCategoria":categorie.nomCategoria,
      "codColor":categorie.codColor,
      "codHobberColor":categorie.codHobberColor,
      "catImagen":categorie.catImagen,
      "usrCreacion": this.getUsrCreacion()
  }
    return this.http
      .put<responseDTO>(url, body)
      .pipe(retry(1), catchError(this.errorHandl));
  }
  public getUsrCreacion(){
    const user= JSON.parse(String(sessionStorage.getItem('user')));
    const prefix = 'BANTCENT';
    return prefix  + String.fromCharCode(92) + user.username.split('@')[0];
  }
  //USUARIOS
  //obtener todos los usuarios
  public obtenerUsers(): Observable<responseDTO> {
    const url = `${this.SERVER_URL}/powerbi/v1/reportes/usuarios/`;
    return this.http
      .get<responseDTO>(url)
      .pipe(retry(1), catchError(this.errorHandl));
  }
   //USUARIOS
  //obtener usuario
  public obtenerUsuario(usuario: string): Observable<responseDTO> {
    const url = `${this.SERVER_URL}/powerbi/v1/reportes/usuarios/`+usuario;
    console.log(' obtener usuario: ', url);
    return this.http
      .get<responseDTO>(url)
      .pipe(retry(1), catchError(this.errorHandl));
  }

  //Agregar usuario desde panel administrador
  public addUser(usuario: userDTO): Observable<userDTO> {
    const url = `${this.SERVER_URL}/powerbi/v1/reportes/usuarios`;
    usuario.usrCreacion=this.getUsrCreacion();
    return this.http
      .post<userDTO>(url, usuario)
      .pipe(retry(1), catchError(this.errorHandl));
  }
  //Eliminar usuario desde panel administrador
  public delUser(idUsuario: string): Observable<responseDTO> {
    const url = `${this.SERVER_URL}/powerbi/v1/reportes/usuarios`;
    return this.http
      .delete<responseDTO>(url + '/' + idUsuario)
      .pipe(retry(1), 
      catchError(this.errorHandl));
  }

  //REPORTES
  //obtener todos los reportes
  public obtenerReportes(): Observable<responseDTO> {
    const url = `${this.SERVER_URL}/powerbi/v1/reportes/`;
    return this.http
      .get<responseDTO>(url)
      .pipe(retry(1), 
      catchError(this.errorHandl));
  }
   /**
    * Agrega reportes
    */
   public addReport(report: any): Observable<responseDTO> {
    const url = `${this.SERVER_URL}/powerbi/v1/reportes`;
    let body={
      "ideReporte": report.ideReporte,
      "nomReporte": report.nomReporte,
      "ideCategoria": Number(report.ideCategoria),
      "usrCreacion": this.getUsrCreacion()
    }

    return this.http
      .post<responseDTO>(url,body)
      .pipe(retry(1));
  }
     /**
    * Modificar reportes
    */
   public editReport(report: any): Observable<responseDTO> {
    const url = `${this.SERVER_URL}/powerbi/v1/reportes`;
    let body={
      "ideReporte": report.ideReporte,
      "ideCategoria": Number(report.ideCategoria),
      "nomReporte": report.nomReporte,
      "usrCreacion": report.usrCreacion
    }
  
    return this.http
      .put<responseDTO>(url, body)
      .pipe(retry(1), 
      catchError(this.errorHandl));
  }
   /**
    * Elimina reportes
    */
   public deleteReport(report: reportDTO): Observable<responseDTO> {
    const url = `${this.SERVER_URL}/powerbi/v1/reportes/`+report.ideReporte;
    return this.http
      .delete<responseDTO>(url)
      .pipe(retry(1), 
      catchError(this.errorHandl));
  }
   //obtener reporte por id
   public obtenerReportebyId(idReporte: string): Observable<responseDTO> {
    const url = `${this.SERVER_URL}/powerbi/v1/reportes/`+idReporte;
    return this.http
      .get<responseDTO>(url)
      .pipe(retry(1), 
      catchError(this.errorHandl));
  }
   /**
    * Obtener catalogo por codigo y subcodigo
    * @param codigo
    * @param subcodigo
    */
   public getCatalogoByCode(codigo: string, subcodigo: string): Observable<responseDTO> {
    const url = `${this.SERVER_URL}/powerbi/v1/reportes/catalogos-usuario/`+codigo+'/'+subcodigo;
    return this.http
      .get<responseDTO>(url)
      .pipe(retry(1), 
      catchError(this.errorHandl));
  }
  /**
   * Obtener catalogos
   */
  public getCatalogs(): Observable<responseDTO> {
    const url = `${this.SERVER_URL}/powerbi/v1/reportes/catalogos/`;
    return this.http
      .get<responseDTO>(url)
      .pipe(retry(1), 
      catchError(this.errorHandl));
  }
    /**
   * Obtener catalogos filtrados
   */
     public filterCatalogs(): Observable<responseDTO> {
      const url = `${this.SERVER_URL}/powerbi/v1/reportes/catalogos-filtrados/`;
      return this.http
        .get<responseDTO>(url)
        .pipe(retry(1), 
        catchError(this.errorHandl));
    }

  // Error handling
  public errorHandl(error: any) {

    let errorMessage = '';
    if (error.error instanceof ErrorEvent) {
      // Get client-side error
      errorMessage = error.error.message;
    } else {
      if(error.error != undefined) {
        if(error.error.message != undefined)
          errorMessage = error.error.message.replace("Error:", "");
      } else  {
        // Get server-side error
        errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
      }
    }
    return throwError(() => {
      return errorMessage;
    });
  }
}
