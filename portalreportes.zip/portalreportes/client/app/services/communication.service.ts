import { Injectable } from '@angular/core';
import { Observable, Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CommunicationService {

  // Observable string sources
  private componentMethodCallSource = new Subject<any>();
  private strBusqueda = new Subject<string>();
  private redirect = new Subject<string>();

  // Observable string streams
  componentMethodCalled$ = this.componentMethodCallSource.asObservable();

  // Service message commands
  callComponentMethod(reportList:any) {
    this.componentMethodCallSource.next(reportList);
  }

  getBusqueda$ = this.strBusqueda.asObservable();
  
  addEvent(strBusqueda: string) {
    this.strBusqueda.next(strBusqueda);
  }


  getRedirect$ = this.redirect.asObservable();
  
  addEventRedirect(redirect: string) {
    this.redirect.next(redirect);
  }
}
