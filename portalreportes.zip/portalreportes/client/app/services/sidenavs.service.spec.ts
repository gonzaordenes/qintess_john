import { TestBed } from '@angular/core/testing';

import { SidenavsService } from './sidenavs.service';

describe('SidenavsService', () => {
  let service: SidenavsService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(SidenavsService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
