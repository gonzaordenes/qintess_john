import { Injectable, Output, EventEmitter } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class SidenavsService {

  @Output() lanzarSidenav: EventEmitter<any> = new EventEmitter();

  constructor() { 
    // implementar
  }
}
