import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EjemploSidenavComponent } from './ejemplo-sidenav.component';

describe('EjemploSidenavComponent', () => {
  let component: EjemploSidenavComponent;
  let fixture: ComponentFixture<EjemploSidenavComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EjemploSidenavComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EjemploSidenavComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
