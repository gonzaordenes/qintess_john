import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ejemplo-sidenav',
  templateUrl: './ejemplo-sidenav.component.html',
  styleUrls: ['./ejemplo-sidenav.component.scss']
})
export class EjemploSidenavComponent implements OnInit {

  constructor() { 
    // implementar
  }

  ngOnInit(): void {
    // implementar
  }

}
