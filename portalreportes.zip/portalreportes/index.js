#!/usr/bin/env node
import express from 'express';
import { join, dirname } from 'path';
import { readFileSync } from 'fs';
import { createServer } from 'https';
import helmet from 'helmet';
import compression from 'compression';

import dotenv from 'dotenv';
dotenv.config({ path: '.env' });

import { fileURLToPath } from 'url';

// Definiendo __filename y __dirname con nueva
const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

import logger from './backend/config/logger.js';
import biconfig from './backend/config/biconfig.js';

// Carga el conenido estático de angular como recurso
const rutaAngular = join(__dirname, '/dist/index.html');

// inicializando Express
const app = express();


app.use(express.json({limit: "10mb", extended: true}));
app.use(express.urlencoded({limit: "10mb", extended: true, parameterLimit: 50000}));

// Helmet para habilitar cabeceras de seguridad
// defaultSrc aplica a Front. sitios habilitados para hacer referencias cruzadas
app.use(
  helmet({
    contentSecurityPolicy: {
      directives: {
        defaultSrc: [
          "'self'",
          'https://login.microsoftonline.com',
          'https://fonts.gstatic.com',
          'https://fonts.googleapis.com',
          'https://graph.microsoft.com',
          'https://aadcdn.msftauthimages.net',
          "'unsafe-inline'",
          'data:']}}}));

//Compresión de fuentes
app.use(compression());

// carga ruta angular como contenido Web estático
app.use(express.static(join(__dirname, '/dist')));

// activando CORS. debe aplicar solo a ambiente local
if(process.env.NODE_ENV === 'local') {
  logger.debug('Desactivando validacion CORS ');
  app.use(function(req, res, next) {
    res.header('Access-Control-Allow-Origin', '*');
    res.header('Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE');
    res.header('Access-Control-Allow-Headers', 'X-API-KEY, Origin, X-Requested-With, Content-Type, Accept, Access-Control-Request-Method',);
    next();
  });
} else {
  logger.debug('Validacion CORS Activada');
}

//rutas de angular
app.route('/:url(welcome|auth|app|admin|usuario\/)').get((req, res) => {
    res.sendFile(rutaAngular);
});


//Carga de middleware y rutas de modulos backend
biconfig(app);

//Remover cabazera x-powered-by
app.disable('x-powered-by');

//HTTPS
try {
  const privateKey  = readFileSync('../trustedcert.key', 'utf8');
  const certificate = readFileSync('../trustedcert.crt', 'utf8');
  const credentials = {key: privateKey, cert: certificate};
  const httpsServer = createServer(credentials, app);

  httpsServer.listen(process.env.APP_PORT);
} catch (error) {
  // Si no encuentra certficados, parte express sin seguridad
  logger.warn('Aplicacion inicia en modo NO SEGURO (sin SSL)');
  // INICIO DEL SERVIDOR
  app.listen(process.env.APP_PORT, () => logger.info(`Server started on port ${process.env.APP_PORT}`));
}
